#!/bin/sh

ip=${FRAMED_IP_ADDRESS}
tun=${DEV}
case $tun in
        "tun0")
            dev="br-lan.10"
            dev_id="0"
            ;;
        "tun2")
            dev="br-lan.200"
            dev_id="2"
            ;;
        "tun4")
            dev="br-lan.14"
            dev_id="4"
            ;;
        "tun5")
            dev="br-lan.15"
            dev_id="5"
            ;;
        "tun6")
            dev="br-lan.16"
            dev_id="6"
            ;;
        "tun7")
            dev="br-lan.17"
            dev_id="7"
            ;;
        *)
            logger "Unknown TUNTAP device: $tun"
            exit 0
            ;;
esac

up=${WISPR_BANDWIDTH_MAX_UP}
dl=${WISPR_BANDWIDTH_MAX_DOWN}
up_mb=$((up / 1000000))
dl_mb=$((dl / 1000000))
mac=${CALLING_STATION_ID}
cnt="$dev_id$(tc class show dev $dev | wc -l)"

ip_entry=$(uci -c /tmp show chilli_users_$dev_id | grep "$ip" | cut -d'=' -f1 | sed 's/\.[^\.]*$//')
if [ -n "$ip_entry" ]; then
    uci -c /tmp delete "$ip_entry"
    uci -c /tmp commit chilli_users_$dev_id
fi

mac_entry=$(uci -c /tmp show chilli_users_$dev_id | grep "$mac" | cut -d'=' -f1 | sed 's/\.[^\.]*$//')
if [ -n "$mac_entry" ]; then
    uci -c /tmp delete "$mac_entry"
    uci -c /tmp commit chilli_users_$dev_id
fi

while :; do
    id_entry=$(uci -c /tmp show chilli_users_$dev_id | grep "id='$cnt'" | cut -d'=' -f1 | sed 's/\.[^\.]*$//' | head -n 1)
    [ -n "$id_entry" ] || break
    uci -c /tmp delete "$id_entry"
    uci -c /tmp commit chilli_users_$dev_id
done

uci -c /tmp add chilli_users_$dev_id device
uci -c /tmp set chilli_users_$dev_id.@device[-1].id="$cnt"
uci -c /tmp set chilli_users_$dev_id.@device[-1].ip="$ip"
uci -c /tmp set chilli_users_$dev_id.@device[-1].mac="$mac"
uci -c /tmp set chilli_users_$dev_id.@device[-1].max_up="$up_mb"
uci -c /tmp set chilli_users_$dev_id.@device[-1].max_down="$dl_mb"
uci -c /tmp commit chilli_users_$dev_id

if [ "$up" = 0 ] || [ "$dl" = 0 ]; then
    logger "Unlimited bandwidth for $mac IP:$ip"
else
    tc class replace dev $dev parent 1:1 classid 1:1$cnt htb rate ${dl_mb}mbit ceil ${dl_mb}mbit
    tc filter replace dev $dev parent 1:0 protocol ip u32 match ip dst $ip flowid 1:1$cnt
    tc class replace dev ${dev}-ifb parent 1:1 classid 1:1$cnt htb rate ${up_mb}mbit ceil ${up_mb}mbit
    tc filter replace dev ${dev}-ifb parent 1:0 protocol ip u32 match ip src $ip flowid 1:1$cnt
    logger "Bandwidth set: UP=${up_mb}Mb/s DOWN=${dl_mb}Mb/s for $mac IP:$ip"
fi
