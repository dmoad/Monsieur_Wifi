# `update.sh` — Deep Analysis

## Overview

`update.sh` is the central device configuration synchronization script for the Halo/Monsieur-WiFi OpenWrt-based access point. It runs on-device and pulls configuration from a remote API, then applies all changes locally using OpenWrt's `uci` (Unified Configuration Interface) system.

The script manages:
- **Wireless** — SSIDs, passwords, visibility, radio parameters (channel, width, TX power, country)
- **Network** — IP addressing, VLAN topology, bridge configuration
- **Chilli (Coova Chilli)** — Captive portal daemon configuration
- **DHCP / dnsmasq** — Address leases, blocked domain redirection, IPv6 filtering
- **MAC Filtering** — Per-radio blacklisting on the password WiFi networks

---

## 1. API Authentication & Data Fetch

```
Lines 1–7
```

```sh
key=$(uci get citypassenger.@device[0].key)
secret=$(uci get citypassenger.@device[0].secret)
api_domain=$(uci get citypassenger.@device[0].api_domain)
api="$api_domain/api/devices/$key/$secret/settings"
response=$(curl -s "$api")
```

- The device identity (`key` + `secret`) is stored in the UCI config `citypassenger`.
- A single `curl` call fetches the full JSON settings blob.
- All subsequent logic parses `$response` with `jq`.

---

## 2. API Response Structure

The full JSON response has four top-level keys:

| Key | Purpose |
|-----|---------|
| `status` | `"success"` or error — gates all further processing |
| `settings` | All device/network/WiFi/captive portal settings |
| `radius_settings` | RADIUS server IP, port, shared secret |
| `guest_settings` | Captive portal login URL, whitelisted IPs/domains |
| `firmware` | Firmware version, download URL, hash |

### Key `settings` fields extracted by the script

| Field | UCI Target | Notes |
|-------|-----------|-------|
| `wifi_name` | `wireless.default_radio0/1.ssid` | Password WiFi SSID |
| `wifi_password` | `wireless.default_radio0/1.key` | Min 8 chars enforced |
| `wifi_visible` | `wireless.default_radio0/1.hidden` | `1`=visible, `0`=hidden |
| `captive_portal_ssid` | `wireless.captive_radio0/1.ssid` | Captive portal SSID |
| `captive_portal_visible` | `wireless.captive_radio0/1.hidden` | Same logic |
| `captive_portal_ip` | `network.network1.ipaddr` + `chilli.dhcplisten` | Gateway for captive net |
| `captive_portal_netmask` | `network.network1.netmask` | |
| `captive_portal_dns1/2` | `network.network1.dns` | Overridden if blocked domains exist |
| `captive_portal_dhcp_start/end` | `chilli.@chilli[0].dhcpstart/end` | Only last octet used |
| `password_wifi_ip` | `network.lan.ipaddr` | |
| `password_wifi_netmask` | `network.lan.netmask` | |
| `password_wifi_ip_mode` | `dhcp.lan.ignore` | `STATIC`=DHCP enabled, `DHCP`=DHCP disabled |
| `password_wifi_dns1/2` | `network.lan.dns` | Overridden if blocked domains exist |
| `password_wifi_dhcp_start/end` | `dhcp.lan.start` + `dhcp.lan.limit` | `limit` = end−start+1 |
| `vlan_enabled` | `network.@bridge-vlan[].vlan_filtering` | Master VLAN toggle |
| `captive_portal_vlan` | `network.network1.device` | `br-lan.<id>` |
| `password_wifi_vlan` | `network.lan.device` | `br-lan.<id>` |
| `captive_portal_vlan_tagging` | bridge-vlan port suffix | `disabled`=untagged, `enabled`=tagged |
| `password_wifi_vlan_tagging` | bridge-vlan port suffix | Same |
| `country_code` | `wireless.radio0/1.country` | |
| `channel_2g/5g` | `wireless.radio0/1.channel` | |
| `channel_width_2g/5g` | `wireless.radio0/1.htmode` | Converted to HE20/40/80/160 |
| `transmit_power_2g/5g` | `wireless.radio0/1.txpower` | dBm |
| `blocked_domains` | `dhcp.@dnsmasq[0].address` | Array of `{domain, ...}` objects |
| `secured_mac_filter_list` | `wireless.default_radio0/1.maclist` | Array of `{mac, type}` objects |

---

## 3. Network Architecture

The device runs **two logical networks** on a single physical bridge (`br-lan`):

```
                    ┌─────────────────────────────────┐
                    │         Physical Bridge          │
                    │            br-lan                │
                    │   (vlan_filtering=1 always)      │
                    │                                  │
                    │  ┌────────────┐ ┌─────────────┐  │
                    │  │  VLAN 10   │ │   VLAN 1    │  │
                    │  │ (default)  │ │  (default)  │  │
                    │  │  Password  │ │   Captive   │  │
                    │  │   WiFi     │ │   Portal    │  │
                    │  └─────┬──────┘ └──────┬──────┘  │
                    └────────┼───────────────┼─────────┘
                             │               │
                    network.lan        network.network1
                    (br-lan.10)        (br-lan.1)
                      dnsmasq            Coova Chilli
                      DHCP server        DHCP + RADIUS
```

### Wireless Interfaces

| UCI Name | Radio | Purpose | Network |
|----------|-------|---------|---------|
| `default_radio0` | radio0 (2.4GHz) | Password WiFi | `lan` |
| `default_radio1` | radio1 (5GHz) | Password WiFi | `lan` |
| `captive_radio0` | radio0 (2.4GHz) | Captive Portal | `network1` |
| `captive_radio1` | radio1 (5GHz) | Captive Portal | `network1` |

---

## 4. VLAN Management — Deep Dive

This is the most complex part of the script. VLAN configuration is handled by a chain of functions.

### 4.1 Function Call Chain

```
configure_vlan_interfaces()
    ├── cleanup_old_bridge_configs()     # Remove legacy br-network1
    ├── cleanup_existing_vlans()         # Delete all bridge-vlan UCI sections
    ├── configure_vlan_filtering()       # Set vlan_filtering=1 on br-lan device
    │       └── ensure_br_lan_device()   # Create br-lan device if missing
    ├── determine_untagged_preference()  # Decide which net gets untagged ports
    │       └── normalize_tagging_value()
    └── configure_bridge_vlan() x2      # Create bridge-vlan UCI sections
            └── get_device_ports()       # Detect physical LAN port names
```

### 4.2 `get_device_ports()` — Physical Port Detection

Probes `/sys/class/net/` in priority order to find available LAN ports:

1. `lan1`, `lan2`, `lan3`, `lan4` — common on many OpenWrt switches
2. `eth1`, `eth2`, `eth3`, `eth4` — fallback for eth-named devices
3. Single `lan` port — some minimal devices
4. Any non-`eth0`, non-WAN, non-wireless interface — last resort scan

WAN ports and wireless interfaces (`wlan*`, `wifi*`) are always excluded.

### 4.3 `ensure_br_lan_device()` — Bridge Creation

If `br-lan` doesn't exist as a UCI `network.device` section, it creates one:

```sh
uci add network device
uci set "network.@device[-1].name=br-lan"
uci set "network.@device[-1].type=bridge"
# Adds each detected physical port:
uci add_list "network.@device[-1].ports=lan1"  # etc.
```

### 4.4 `configure_vlan_filtering()` — Enable/Disable VLAN Filtering

Finds the `br-lan` device UCI section by name and sets:

```sh
uci set "network.<section>.vlan_filtering=1"   # always 1 in current code
```

> **Note:** Even when `vlan_enabled=false` from the API, the script still sets `vlan_filtering=1`. This means VLAN separation is always active; the `vlan_enabled` flag only controls whether API-supplied VLAN IDs are used vs. the hardcoded defaults (10 and 1).

### 4.5 `cleanup_existing_vlans()` — Idempotent VLAN Cleanup

Uses a `while true` loop to delete `network.@bridge-vlan[0]` repeatedly until none remain. This ensures a clean slate before reconfiguration.

### 4.6 `determine_untagged_preference()` — Tagging Logic

Takes `captive_portal_vlan_tagging` and `password_wifi_vlan_tagging` from the API. Values are normalized first:

| Raw API value | Normalized |
|--------------|-----------|
| `"disabled"` | `"disabled"` (= untagged) |
| `"untagged"` | `"disabled"` (= untagged) |
| `"enabled"` | `"enabled"` (= tagged) |
| `"tagged"` | `"enabled"` (= tagged) |
| anything else | `"enabled"` (default) |

Decision matrix for which network gets the `u*` (PVID/untagged) port:

| captive_portal_vlan_tagging | password_wifi_vlan_tagging | Result |
|----------------------------|---------------------------|--------|
| `disabled` | `disabled` | `lan` gets untagged |
| `disabled` | `enabled` | `captive` gets untagged |
| `enabled` | `disabled` | `lan` gets untagged |
| `enabled` | `enabled` | `both_tagged` |

### 4.7 `configure_bridge_vlan()` — UCI bridge-vlan Section Creation

For each VLAN, creates a UCI `bridge-vlan` section:

```sh
uci add network bridge-vlan
uci set "network.@bridge-vlan[-1].device=br-lan"
uci set "network.@bridge-vlan[-1].vlan=<id>"

# For each physical port:
uci add_list "network.@bridge-vlan[-1].ports=lan1:u*"   # untagged (PVID)
# OR
uci add_list "network.@bridge-vlan[-1].ports=lan1:t"    # tagged
```

The `:u*` suffix sets the port as **untagged with PVID** (traffic ingressing untagged gets assigned this VLAN). The `:t` suffix means the port carries this VLAN **tagged**.

### 4.8 Full VLAN Scenario Matrix

#### Scenario A: `vlan_enabled=true`

Uses VLAN IDs from API (`captive_portal_vlan`, `password_wifi_vlan`).
Falls back to defaults (VLAN 10 for LAN, VLAN 1 for captive) if API values are `null` or invalid.

**Sub-scenario A1: `untagged_preference=lan`** (most common — both disabled or only LAN disabled)
```
br-lan bridge-vlan:
  VLAN <password_wifi_vlan>   → lan ports: u*   (untagged/PVID)
  VLAN <captive_portal_vlan>  → lan ports: t    (tagged)

network.lan.device    = br-lan.<password_wifi_vlan>
network.network1.device = br-lan.<captive_portal_vlan>
```

**Sub-scenario A2: `untagged_preference=captive`** (only captive disabled)
```
br-lan bridge-vlan:
  VLAN <password_wifi_vlan>   → lan ports: t    (tagged)
  VLAN <captive_portal_vlan>  → lan ports: u*   (untagged/PVID)

network.lan.device    = br-lan.<password_wifi_vlan>
network.network1.device = br-lan.<captive_portal_vlan>
```

**Sub-scenario A3: `untagged_preference=both_tagged`** (both enabled)
```
br-lan bridge-vlan:
  VLAN <password_wifi_vlan>   → lan ports: t    (tagged)
  VLAN <captive_portal_vlan>  → lan ports: t    (tagged)

network.lan.device    = br-lan.<password_wifi_vlan>
network.network1.device = br-lan.<captive_portal_vlan>
```

#### Scenario B: `vlan_enabled=false`

Always uses defaults: VLAN 10 (LAN), VLAN 1 (captive). Tagging preference still applies.

```
br-lan bridge-vlan:
  VLAN 10  → based on untagged_preference
  VLAN 1   → based on untagged_preference

network.lan.device    = br-lan.10
network.network1.device = br-lan.1
```

### 4.9 Example with Provided API Response

From the sample JSON:
```json
"vlan_enabled": true,
"captive_portal_vlan": null,
"password_wifi_vlan": null,
"captive_portal_vlan_tagging": "disabled",
"password_wifi_vlan_tagging": "disabled"
```

**Result:**
- Both VLANs null → defaults: `password_wifi_vlan=10`, `captive_portal_vlan=1`
- Both tagging `disabled` → `untagged_preference = "lan"`
- Bridge-VLAN:
  - VLAN 10: `lan1:u*`, `lan2:u*`, ... (untagged, PVID)
  - VLAN 1: `lan1:t`, `lan2:t`, ... (tagged)
- `network.lan.device = br-lan.10`
- `network.network1.device = br-lan.1`

---

## 5. Chilli (Coova Chilli) Interface Configuration

Chilli handles DHCP and authentication for the captive portal network. The script manages these UCI keys:

| UCI Key | Source | Example Value |
|---------|--------|--------------|
| `chilli.@chilli[0].net` | Derived from `captive_portal_ip` | `192.168.2.0/24` |
| `chilli.@chilli[0].dynip` | Same as `net` | `192.168.2.0/24` |
| `chilli.@chilli[0].dhcplisten` | `captive_portal_ip` directly | `192.168.2.1` |
| `chilli.@chilli[0].dhcpif` | Derived from VLAN config | `br-lan.1` or `br-lan.<captive_vlan>` |
| `chilli.@chilli[0].dhcpstart` | Last octet of `captive_portal_dhcp_start` | `100` |
| `chilli.@chilli[0].dhcpend` | Last octet of `captive_portal_dhcp_end` | `200` |
| `chilli.@chilli[0].dns1` | `captive_portal_ip` (always local) | `192.168.2.1` |
| `chilli.@chilli[0].dns2` | `captive_portal_ip` (always local) | `192.168.2.1` |
| `chilli.@chilli[0].radiusserver1` | `radius_settings.radius_ip` | `51.75.23.245` |
| `chilli.@chilli[0].radiusserver2` | `radius_settings.radius_ip` | `51.75.23.245` |
| `chilli.@chilli[0].radiussecret` | `radius_settings.radius_secret` | `xNq7TaV3...` |
| `chilli.@chilli[0].uamserver` | `guest_settings.login_url` | `https://portal.monsieur-wifi.com/guest-login` |
| `chilli.@chilli[0].uamallowed` | `guest_settings.whitelist_servers` | `145.32.139.116,...` |
| `chilli.@chilli[0].uamdomain` | `guest_settings.whitelist_domains` | `.cnctdwifi.com,...` |
| `chilli.@chilli[0].radiusnasid` | `settings.location_id` (from `.location.id`) | `12` |

### Chilli `dhcpif` — Critical VLAN Binding

`dhcpif` tells Chilli which network interface to listen on for DHCP. This must match the bridge VLAN sub-interface of the captive portal network:

```sh
# VLAN mode enabled:
chilli.dhcpif = "br-lan.<captive_portal_vlan>"   # e.g. br-lan.1

# VLAN mode disabled:
chilli.dhcpif = "br-lan.1"                        # always VLAN 1 default
```

This binding is set in **two places** in the script:
1. When `chilli_ip` changes (inside the chilli IP change block)
2. **Unconditionally** after `configure_vlan_interfaces()` completes — ensuring it's always correct even if the IP didn't change

### Chilli `net` Derivation

The `net` field requires network address notation (`x.x.x.0/24`), not a host IP:

```sh
captive_portal_ip="192.168.2.1"
captive_portal_ip_base=$(echo "$captive_portal_ip" | cut -d. -f1-3)  # "192.168.2"
chilli_ip="$captive_portal_ip_base.0/24"                              # "192.168.2.0/24"
```

### DNS in Chilli

Chilli DNS1 and DNS2 are both set to the **local captive portal IP** (not external DNS). This means all DNS queries from captive portal clients go to the local dnsmasq instance first, enabling domain-level blocking before packets leave the device.

---

## 6. `conup.sh` Patch

After VLAN reconfiguration, the script patches `/etc/chilli/conup.sh` in-place using `sed`:

```sh
sed -i 's/^[[:space:]]*dev=.*/            dev="br-lan.<vlan>"/' /etc/chilli/conup.sh
```

`conup.sh` is Chilli's connection-up hook (runs when a client authenticates). The `dev=` line specifies which interface to apply firewall/routing rules on. It must be kept in sync with `dhcpif`.

---

## 7. DNS & Domain Blocking

### Blocked Domains Architecture

When `blocked_domains` is a non-empty array in the API response, the script:

1. **dnsmasq address records** — Redirects blocked domains to the captive portal IP:
   ```sh
   uci add_list dhcp.@dnsmasq[0].address="/<domain>/<captive_portal_ip>"
   # e.g. /facebook.com/192.168.2.1
   ```

2. **DNS server override** — Forces both WiFi networks to use the local device as DNS:
   - Password WiFi: `network.lan.dns` → `password_wifi_ip` (local gateway)
   - Captive Portal: `network.network1.dns` → `captive_portal_ip` (local gateway)

3. **IPv6 AAAA filtering** — Prevents DNS-over-IPv6 bypassing blocks:
   ```sh
   uci set dhcp.@dnsmasq[0].filter_aaaa=1
   ```

4. **DNS filtering service** — Starts `/etc/init.d/dns_filtering` and enables it for boot. Flagged by `/tmp/dns_redirect_enabled`.

When no blocked domains exist, all of the above are reversed/disabled.

### DNS Logic Summary

```
blocked_domains present?
    YES → LAN DNS = local LAN IP, Captive DNS = captive portal IP
          dnsmasq address records → captive portal IP
          filter_aaaa = 1
          dns_filtering service → start + enable
    NO  → LAN DNS = API dns1/dns2, Captive DNS = API dns1/dns2
          dnsmasq address records → cleared
          filter_aaaa = 0
          dns_filtering service → stop + disable
```

---

## 8. Wireless Radio Configuration

### Radio Mapping

| UCI Radio | Band | SSIDs |
|-----------|------|-------|
| `radio0` | 2.4GHz | `default_radio0` (password), `captive_radio0` (captive) |
| `radio1` | 5GHz | `default_radio1` (password), `captive_radio1` (captive) |

### Channel Width → htmode Conversion

```
Width  │ Band  │ htmode
───────┼───────┼────────
20MHz  │ any   │ HE20
40MHz  │ any   │ HE40
80MHz  │ 5GHz  │ HE80
160MHz │ 5GHz  │ HE160
```

HE (High Efficiency) mode implies Wi-Fi 6 (802.11ax) capability. Default fallback: `HE40` for 2.4GHz, `HE80` for 5GHz.

### From Sample API Response

| Parameter | Value | UCI Setting |
|-----------|-------|-------------|
| Country | `FR` | `wireless.radio0/1.country=FR` |
| 2.4GHz channel | `4` | `wireless.radio0.channel=4` |
| 2.4GHz width | `40MHz` | `wireless.radio0.htmode=HE40` |
| 2.4GHz power | `15dBm` | `wireless.radio0.txpower=15` |
| 5GHz channel | `149` | `wireless.radio1.channel=149` |
| 5GHz width | `80MHz` | `wireless.radio1.htmode=HE80` |
| 5GHz power | `17dBm` | `wireless.radio1.txpower=17` |

---

## 9. MAC Address Filtering

Only applies to the **password WiFi** networks (`default_radio0/1`). Only **blacklist** type entries from `secured_mac_filter_list` are processed; whitelist entries in this list are silently ignored.

```json
"secured_mac_filter_list": [{"mac": "E4:0C:FD:7B:1C:A7", "type": "blacklist"}]
```

| Condition | UCI Result |
|-----------|-----------|
| Blacklist MACs present | `macfilter=deny`, `maclist=[MACs...]` on both radios |
| No blacklist MACs (or list empty/null) | `macfilter=disable`, `maclist` deleted on both radios |

Captive portal radios (`captive_radio0/1`) are **not** subject to MAC filtering by this script.

---

## 10. Change Detection & Service Restart Logic

The script only applies changes when the current value differs from the desired value. Boolean flags track what changed:

| Flag | Triggers Restart of |
|------|-------------------|
| `ssid_changed` | `wifi reload` (or `wifi down/up` if radio also changed) |
| `password_changed` | Same |
| `visibility_changed` | `chilli restart` + wireless restart |
| `radio_changed` | `wifi down && sleep 3 && wifi up` (full cycle) |
| `mac_filter_changed` | `wifi down && sleep 3 && wifi up` (full cycle) |
| `captive_ssid_changed` | `chilli restart` |
| `chilli_changed` | `chilli restart` |
| `dhcp_changed` | `dnsmasq restart` |
| `network_changed` | `network restart` + `ensure_bridge_configuration()` |
| `domains_changed` | `dnsmasq restart` |

### Network Restart Special Case

Network restart is triggered whenever `vlan_enabled` has any value (i.e., always when the API responds with success), because VLAN configuration always needs reapplication:

```sh
if [ "$network_changed" = true ] || [ "$vlan_enabled" = "true" ] || [ "$vlan_enabled" = "false" ]; then
    /etc/init.d/network restart
    ensure_bridge_configuration
fi
```

`ensure_bridge_configuration()` then verifies `br-lan` comes up with the correct IP after the restart (with a 3-second wait).

---

## 11. Password WiFi IP Mode

The `password_wifi_ip_mode` field controls whether the LAN interface acts as a DHCP server or client:

| API Value | Behavior |
|-----------|---------|
| `STATIC` / `static` | Applies `password_wifi_ip` + `password_wifi_netmask` to `network.lan`. Enables dnsmasq DHCP (`dhcp.lan.ignore=0`) |
| `DHCP` / `dhcp` | Does not configure a static IP. Disables dnsmasq DHCP (`dhcp.lan.ignore=1`) — device acts as DHCP client on LAN |

IP and netmask undergo validation before being applied. Invalid values fall back to `192.168.100.1/255.255.255.0`.

---

## 12. Execution Flow Summary

```
1.  Fetch API response (curl)
2.  Check status == "success"
3.  Extract all settings fields via jq
4.  Read all current UCI values
5.  Initialize change flags
6.  Update WiFi visibility (hidden flag) → flag: visibility_changed
7.  Update SSIDs → flag: ssid_changed, captive_ssid_changed
8.  Update WiFi password → flag: password_changed
9.  Update radio settings (country, channel, width, txpower) → flag: radio_changed
10. Commit wireless if any wireless flags set
11. Update chilli whitelist servers/domains (legacy path, commented out)
12. Update chilli net/dynip/dhcplisten/dhcpif → flag: chilli_changed
13. Update captive portal netmask → flag: network_changed
14. Update chilli DNS1/DNS2 (always captive_portal_ip)
15. Handle captive portal DNS in network.network1 (based on blocked_domains)
16. Handle password_wifi_ip_mode (STATIC or DHCP) → flags: network_changed, dhcp_changed
17. Handle captive portal DHCP range → flag: chilli_changed
18. Handle password WiFi DHCP range → flag: dhcp_changed
19. Check blocked_domains → set has_blocked_domains
20. Handle password WiFi DNS (local or API) → flag: network_changed
21. Restart dnsmasq if dhcp_changed
22. Configure VLAN interfaces (big function chain) → commits network
23. Update chilli dhcpif unconditionally → flag: chilli_changed
24. Patch conup.sh with correct dev= interface
25. Restart network (always, due to VLAN logic)
26. ensure_bridge_configuration() (verify br-lan IP post-restart)
27. Restart chilli if captive_ssid_changed or visibility_changed
28. Update chilli RADIUS/UAM/NAS settings → flag: chilli_changed
29. Restart chilli if chilli_changed
30. Handle blocked_domains → update dnsmasq address records → flag: domains_changed
31. Update filter_aaaa based on blocked_domains → flag: domains_changed
32. Restart dnsmasq if domains_changed
33. Start/stop/enable/disable dns_filtering service
34. Handle MAC filtering → flag: mac_filter_changed
35. Final wireless restart (wifi down/up or wifi reload based on what changed)
```

---

## 13. From the Sample API Response — Complete Configuration Applied

Given the provided JSON example, this is what the script would configure:

### Network Topology
```
br-lan (vlan_filtering=1)
├── br-lan.10  → network.lan    (192.168.15.1/24, VLAN 10 untagged on all LAN ports)
└── br-lan.1   → network.network1 (192.168.2.1/24, VLAN 1 tagged on all LAN ports)
```

### Password WiFi (SSID: `WIFI_SDV`)
- IP: `192.168.15.1/255.255.255.0`
- DHCP: enabled, range `.100`–`.200` (limit=101)
- DNS: `8.8.8.8`, `8.8.4.4`
- MAC Blacklist: `E4:0C:FD:7B:1C:A7`

### Captive Portal (SSID: `WiFi GuestD`)
- Chilli IP: `192.168.2.1`, net: `192.168.2.0/24`
- Chilli dhcpif: `br-lan.1`
- DHCP range: `.100`–`.200`
- DNS: `192.168.2.1` (local, both dns1 and dns2)
- RADIUS: `51.75.23.245:1812`, secret: `xNq7TaV3LmP9WrJkY2XoBz6CdQ`
- UAM server: `https://portal.monsieur-wifi.com/guest-login`
- UAM allowed: `145.32.139.116,mrwifi.cnctdwifi.com`
- UAM domains: `.cnctdwifi.com,.halowifi.com`
- NAS ID (radiusnasid): `12`

### Radio
- Country: `FR`
- 2.4GHz: channel 4, HE40, 15dBm
- 5GHz: channel 149, HE80, 17dBm

### Blocked Domains
- `blocked_domains: []` → no blocking, filter_aaaa=0, dns_filtering service disabled
