#!/bin/sh
#
# save-backup.sh - Save current UCI config as the restore baseline.
#
# Run this ONCE after bootstrap-slots.sh has been run and the config
# is in the desired baseline state. On every subsequent boot, rc.local
# will restore from this backup before update-v2.sh runs.
#
# Backup location: /root/backup_config
#

BACKUP_DIR="/root/backup_config"

mkdir -p "$BACKUP_DIR"

for f in network wireless dhcp chilli firewall; do
    if [ -f "/etc/config/$f" ]; then
        cp "/etc/config/$f" "$BACKUP_DIR/$f"
        echo "Saved /etc/config/$f -> $BACKUP_DIR/$f"
    else
        echo "WARNING: /etc/config/$f not found, skipping"
    fi
done

echo ""
echo "Backup saved to $BACKUP_DIR"
echo "Files:"
ls -la "$BACKUP_DIR/"
