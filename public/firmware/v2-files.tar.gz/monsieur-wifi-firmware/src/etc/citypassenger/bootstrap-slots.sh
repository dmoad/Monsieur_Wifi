#!/bin/sh
#
# bootstrap-slots.sh - One-time setup for multi-network slot infrastructure
#
# Run this ONCE on a device to pre-create all 8 UCI slots used by update-v2.sh.
# Each slot is created in a fully disabled state, except slot 0 which is
# activated as a password network (SSID: monsieur-wifi, key: abcd1234).
#
# Slots:
#   Slot N -> UCI network:   net_N
#          -> UCI wireless:  wifi_N_radio0 (2.4GHz), wifi_N_radio1 (5GHz)
#          -> UCI DHCP:      dhcp_net_N
#          -> UCI Chilli:    chilli_N  (in /etc/config/chilli)
#          -> Bridge VLAN:   br-lan.(10+N)  (VLAN 10..17)
#
# Safe to re-run -- exits immediately if already fully applied.
# Requires: uci (OpenWrt), sh (BusyBox ash), no bash-isms used.
#

echo "========================================="
echo "Multi-network slot bootstrap"
echo "========================================="

# ---------------------------------------------------------------------------
# 0. Early-exit guard: check if all 8 slots are already fully configured.
#    Checks net_0..7, wifi_0_radio0..wifi_7_radio1, dhcp_net_0..7, chilli_0..7
#    and that net_0 is in the lan firewall zone. If all present, exit cleanly.
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 0: Checking if bootstrap already applied ---"

already_done=1

slot=0
while [ "$slot" -le 7 ]; do
    uci get "network.net_${slot}"          >/dev/null 2>&1 || { already_done=0; break; }
    uci get "wireless.wifi_${slot}_radio0" >/dev/null 2>&1 || { already_done=0; break; }
    uci get "wireless.wifi_${slot}_radio1" >/dev/null 2>&1 || { already_done=0; break; }
    uci get "dhcp.dhcp_net_${slot}"        >/dev/null 2>&1 || { already_done=0; break; }
    uci get "chilli.chilli_${slot}"        >/dev/null 2>&1 || { already_done=0; break; }
    slot=$((slot + 1))
done

if [ "$already_done" -eq 1 ]; then
    # Verify all 8 bridge-vlan sections for VLANs 10-17 exist
    bvlan_check=0
    idx=0
    while true; do
        vlan_val=$(uci get "network.@bridge-vlan[$idx].vlan" 2>/dev/null) || break
        case "$vlan_val" in
            10|11|12|13|14|15|16|17) bvlan_check=$((bvlan_check + 1)) ;;
        esac
        idx=$((idx + 1))
    done
    [ "$bvlan_check" -lt 8 ] && already_done=0
fi

if [ "$already_done" -eq 1 ]; then
    # Verify net_0 is in the lan firewall zone
    net0_in_fw=0
    idx=0
    while true; do
        zone_name=$(uci get "firewall.@zone[$idx].name" 2>/dev/null) || break
        if [ "$zone_name" = "lan" ]; then
            for n in $(uci get "firewall.@zone[$idx].network" 2>/dev/null); do
                [ "$n" = "net_0" ] && net0_in_fw=1
            done
            break
        fi
        idx=$((idx + 1))
    done
    [ "$net0_in_fw" -eq 0 ] && already_done=0
fi

if [ "$already_done" -eq 1 ]; then
    echo "  Bootstrap already applied. Nothing to do."
    echo "========================================="
    exit 0
fi

echo "  Bootstrap not yet fully applied, continuing..."

# ---------------------------------------------------------------------------
# 1. Ensure br-lan device section has vlan_filtering enabled
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 1: Configure br-lan bridge with VLAN filtering ---"

# uci show output format: network.@device[N].name='br-lan'
# sed strips everything from .name= onward, leaving e.g. network.@device[0]
brlan_section=""
brlan_section=$(uci show network 2>/dev/null | grep "\.name='br-lan'" | sed "s/\.name=.*//" | head -1)

if [ -z "$brlan_section" ]; then
    echo "  br-lan device section not found, creating..."
    uci add network device
    uci set "network.@device[-1].name=br-lan"
    uci set "network.@device[-1].type=bridge"

    # Detect LAN ports - try numbered ports first, then single 'lan', then eth1+
    ports_added=0
    for port in lan1 lan2 lan3 lan4; do
        if [ -e "/sys/class/net/$port" ]; then
            uci add_list "network.@device[-1].ports=$port"
            ports_added=$((ports_added + 1))
        fi
    done
    if [ "$ports_added" -eq 0 ] && [ -e "/sys/class/net/lan" ]; then
        uci add_list "network.@device[-1].ports=lan"
        ports_added=1
    fi
    if [ "$ports_added" -eq 0 ]; then
        for port in eth1 eth2 eth3 eth4; do
            if [ -e "/sys/class/net/$port" ]; then
                uci add_list "network.@device[-1].ports=$port"
                ports_added=$((ports_added + 1))
            fi
        done
    fi
    uci set "network.@device[-1].vlan_filtering=1"
    echo "  br-lan device created with vlan_filtering=1 ($ports_added port(s) added)"
else
    echo "  br-lan device found at: $brlan_section"
    uci set "${brlan_section}.vlan_filtering=1"
    echo "  vlan_filtering=1 applied"
fi

uci commit network
echo "  network committed."

# ---------------------------------------------------------------------------
# 2. Remove legacy anonymous chilli section (conflicts with named chilli_N)
#    The original /etc/config/chilli has one unnamed `config chilli` block.
#    UCI names it @chilli[0]. Deletes all such anonymous entries.
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 2: Clean up legacy anonymous chilli section ---"

removed_chilli=0
while uci delete "chilli.@chilli[0]" 2>/dev/null; do
    removed_chilli=$((removed_chilli + 1))
done
if [ "$removed_chilli" -gt 0 ]; then
    uci commit chilli
    echo "  Removed $removed_chilli anonymous chilli section(s)."
else
    echo "  No anonymous chilli sections found."
fi

# ---------------------------------------------------------------------------
# 3. Remove any wifi-iface sections with SSID MrWiFi-Password or MrWiFi-Open
#    Scan all wifi-iface sections and delete matching ones before creating slots.
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 3: Remove legacy MrWiFi-Password / MrWiFi-Open SSIDs ---"

wifi_removed=0

# Pass 1: anonymous @wifi-iface sections — do NOT increment idx after delete,
# the next section shifts down into the same index position.
idx=0
while true; do
    ssid=$(uci get "wireless.@wifi-iface[$idx].ssid" 2>/dev/null) || break
    if [ "$ssid" = "MrWiFi-Password" ] || [ "$ssid" = "MrWiFi-Open" ]; then
        echo "  Removing @wifi-iface[$idx] with SSID=$ssid"
        uci delete "wireless.@wifi-iface[$idx]"
        wifi_removed=$((wifi_removed + 1))
    else
        idx=$((idx + 1))
    fi
done

# Pass 2: named (non-anonymous) sections only — skip any @-prefixed names
# to avoid re-processing anonymous sections already handled above.
for section in $(uci show wireless 2>/dev/null | grep "=wifi-iface" | cut -d'=' -f1 | sed 's/wireless\.//' | grep -v '^@'); do
    ssid=$(uci get "wireless.${section}.ssid" 2>/dev/null) || continue
    if [ "$ssid" = "MrWiFi-Password" ] || [ "$ssid" = "MrWiFi-Open" ]; then
        echo "  Removing named section wireless.$section with SSID=$ssid"
        uci delete "wireless.${section}"
        wifi_removed=$((wifi_removed + 1))
    fi
done

if [ "$wifi_removed" -gt 0 ]; then
    uci commit wireless
    echo "  Removed $wifi_removed legacy SSID section(s) and committed."
else
    echo "  No MrWiFi-Password or MrWiFi-Open sections found."
fi

# ---------------------------------------------------------------------------
# 4. Create network interface slots (net_0 .. net_7)  [comment matches Step 4]
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 4: Create network interface slots ---"

slot=0
while [ "$slot" -le 7 ]; do
    net_name="net_${slot}"
    vlan_id=$((10 + slot))
    default_ip="172.16.${vlan_id}.1"

    if uci get "network.${net_name}" >/dev/null 2>&1; then
        echo "  $net_name already exists, skipping"
    else
        echo "  Creating $net_name (device=br-lan.${vlan_id}, ip=${default_ip})"
        uci set "network.${net_name}=interface"
        uci set "network.${net_name}.proto=static"
        uci set "network.${net_name}.device=br-lan.${vlan_id}"
        uci set "network.${net_name}.ipaddr=${default_ip}"
        uci set "network.${net_name}.netmask=255.255.255.0"
    fi

    slot=$((slot + 1))
done

uci commit network
echo "  Network slots committed."

# ---------------------------------------------------------------------------
# 5. Create wireless interface slots (wifi_N_radio0, wifi_N_radio1)
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 5: Create wireless interface slots ---"

slot=0
while [ "$slot" -le 7 ]; do
    net_name="net_${slot}"

    for radio in radio0 radio1; do
        wifi_name="wifi_${slot}_${radio}"

        if uci get "wireless.${wifi_name}" >/dev/null 2>&1; then
            echo "  $wifi_name already exists, skipping"
        else
            echo "  Creating $wifi_name (network=${net_name}, disabled)"
            uci set "wireless.${wifi_name}=wifi-iface"
            uci set "wireless.${wifi_name}.device=${radio}"
            uci set "wireless.${wifi_name}.network=${net_name}"
            uci set "wireless.${wifi_name}.mode=ap"
            uci set "wireless.${wifi_name}.ssid=slot_${slot}_disabled"
            uci set "wireless.${wifi_name}.encryption=none"
            uci set "wireless.${wifi_name}.disabled=1"
        fi
    done

    slot=$((slot + 1))
done

uci commit wireless
echo "  Wireless slots committed."

# ---------------------------------------------------------------------------
# 6. Create DHCP slots (dhcp_net_0 .. dhcp_net_7)
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 6: Create DHCP slots ---"

slot=0
while [ "$slot" -le 7 ]; do
    dhcp_name="dhcp_net_${slot}"
    net_name="net_${slot}"

    if uci get "dhcp.${dhcp_name}" >/dev/null 2>&1; then
        echo "  $dhcp_name already exists, skipping"
    else
        echo "  Creating $dhcp_name (interface=${net_name}, ignore=1)"
        uci set "dhcp.${dhcp_name}=dhcp"
        uci set "dhcp.${dhcp_name}.interface=${net_name}"
        uci set "dhcp.${dhcp_name}.start=100"
        uci set "dhcp.${dhcp_name}.limit=100"
        uci set "dhcp.${dhcp_name}.leasetime=12h"
        uci set "dhcp.${dhcp_name}.ignore=1"
    fi

    slot=$((slot + 1))
done

uci commit dhcp
echo "  DHCP slots committed."

# ---------------------------------------------------------------------------
# 7. Create Chilli slots (chilli_0 .. chilli_7)
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 7: Create Chilli slots ---"

slot=0
while [ "$slot" -le 7 ]; do
    chilli_name="chilli_${slot}"
    vlan_id=$((10 + slot))
    default_net_ip=$((100 + slot))
    default_net="172.16.${default_net_ip}.0/24"
    default_listen="172.16.${default_net_ip}.1"

    if uci get "chilli.${chilli_name}" >/dev/null 2>&1; then
        echo "  $chilli_name already exists, skipping"
    else
        echo "  Creating $chilli_name (tun${slot}, dhcpif=br-lan.${vlan_id}, disabled)"
        uci set "chilli.${chilli_name}=chilli"
        uci set "chilli.${chilli_name}.disabled=1"
        uci set "chilli.${chilli_name}.tundev=tun${slot}"
        uci set "chilli.${chilli_name}.dhcpif=br-lan.${vlan_id}"
        uci set "chilli.${chilli_name}.net=${default_net}"
        uci set "chilli.${chilli_name}.dynip=${default_net}"
        uci set "chilli.${chilli_name}.dhcplisten=${default_listen}"
        uci set "chilli.${chilli_name}.dns1=${default_listen}"
        uci set "chilli.${chilli_name}.dns2=${default_listen}"
        uci set "chilli.${chilli_name}.ipup=/etc/chilli/up.sh"
        uci set "chilli.${chilli_name}.ipdown=/etc/chilli/down.sh"
        uci set "chilli.${chilli_name}.conup=/etc/chilli/conup.sh"
        uci set "chilli.${chilli_name}.wwwdir=/etc/chilli/www"
        uci set "chilli.${chilli_name}.wwwbin=/etc/chilli/wwwsh"
        uci set "chilli.${chilli_name}.kname=${chilli_name}"
        uci set "chilli.${chilli_name}.uamaliasname=${chilli_name}"
    fi

    slot=$((slot + 1))
done

uci commit chilli
echo "  Chilli slots committed."

# ---------------------------------------------------------------------------
# 8. Create bridge-vlan sections for VLANs 10-17
#    Always rebuilds from scratch (delete all, then re-add 8 sections).
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 8: Create bridge-vlan sections (VLANs 10-17) ---"

# Count how many bridge-vlan sections already exist for VLANs 10-17
bvlan_count=0
idx=0
while true; do
    vlan_val=$(uci get "network.@bridge-vlan[$idx].vlan" 2>/dev/null) || break
    case "$vlan_val" in
        10|11|12|13|14|15|16|17) bvlan_count=$((bvlan_count + 1)) ;;
    esac
    idx=$((idx + 1))
done

if [ "$bvlan_count" -ge 8 ]; then
    echo "  All 8 bridge-vlan sections already exist, skipping."
else
    removed=0
    while uci delete "network.@bridge-vlan[0]" 2>/dev/null; do
        removed=$((removed + 1))
    done
    echo "  Removed $removed existing bridge-vlan section(s)"

    # Detect physical LAN ports (POSIX-safe, no xargs/arrays)
    ports=""
    for port in lan1 lan2 lan3 lan4; do
        if [ -e "/sys/class/net/$port" ]; then
            if [ -z "$ports" ]; then
                ports="$port"
            else
                ports="$ports $port"
            fi
        fi
    done
    if [ -z "$ports" ] && [ -e "/sys/class/net/lan" ]; then
        ports="lan"
    fi
    if [ -z "$ports" ]; then
        for port in eth1 eth2 eth3 eth4; do
            if [ -e "/sys/class/net/$port" ]; then
                if [ -z "$ports" ]; then
                    ports="$port"
                else
                    ports="$ports $port"
                fi
            fi
        done
    fi

    if [ -z "$ports" ]; then
        echo "  WARNING: No physical LAN ports detected"
        echo "  Add ports manually: uci add_list network.@bridge-vlan[N].ports=<port>:u*"
    else
        echo "  Detected LAN ports: $ports"
    fi

    slot=0
    while [ "$slot" -le 7 ]; do
        vlan_id=$((10 + slot))
        echo "  Creating bridge-vlan VLAN $vlan_id (slot $slot)"
        uci add network bridge-vlan
        uci set "network.@bridge-vlan[-1].device=br-lan"
        uci set "network.@bridge-vlan[-1].vlan=${vlan_id}"
        if [ -n "$ports" ]; then
            for port in $ports; do
                uci add_list "network.@bridge-vlan[-1].ports=${port}:u*"
            done
        fi
        slot=$((slot + 1))
    done

    uci commit network
    echo "  Bridge-VLAN sections committed."
fi

# ---------------------------------------------------------------------------
# 9. Disable legacy named wifi-iface sections (default_radio0/1, captive_radio0/1)
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 9: Disable legacy wifi-iface sections ---"

for legacy in default_radio0 default_radio1 captive_radio0 captive_radio1; do
    if uci get "wireless.${legacy}" >/dev/null 2>&1; then
        uci set "wireless.${legacy}.disabled=1"
        echo "  Disabled wireless.${legacy}"
    else
        echo "  wireless.${legacy} not found, skipping"
    fi
done

uci commit wireless
echo "  Legacy wireless sections disabled."

echo ""
echo "--- Step 10: Activate slot 0 (monsieur-wifi, psk2) ---"

# Network interface - only set if values differ from target
net0_ip=$(uci get "network.net_0.ipaddr" 2>/dev/null)
net0_dev=$(uci get "network.net_0.device" 2>/dev/null)
if [ "$net0_ip" != "172.16.10.1" ] || [ "$net0_dev" != "br-lan.10" ]; then
    uci set "network.net_0.proto=static"
    uci set "network.net_0.device=br-lan.10"
    uci set "network.net_0.ipaddr=172.16.10.1"
    uci set "network.net_0.netmask=255.255.255.0"
    uci commit network
    echo "  network.net_0 set (br-lan.10, 172.16.10.1)"
else
    echo "  network.net_0 already correct, skipping"
fi

# Wireless - only set if SSID or disabled state differs
wifi0_ssid=$(uci get "wireless.wifi_0_radio0.ssid" 2>/dev/null)
wifi0_dis=$(uci get "wireless.wifi_0_radio0.disabled" 2>/dev/null)
if [ "$wifi0_ssid" != "monsieur-wifi" ] || [ "$wifi0_dis" != "0" ]; then
    uci set "wireless.wifi_0_radio0.ssid=monsieur-wifi"
    uci set "wireless.wifi_0_radio0.encryption=psk2"
    uci set "wireless.wifi_0_radio0.key=abcd1234"
    uci set "wireless.wifi_0_radio0.hidden=0"
    uci set "wireless.wifi_0_radio0.disabled=0"

    uci set "wireless.wifi_0_radio1.ssid=monsieur-wifi"
    uci set "wireless.wifi_0_radio1.encryption=psk2"
    uci set "wireless.wifi_0_radio1.key=abcd1234"
    uci set "wireless.wifi_0_radio1.hidden=0"
    uci set "wireless.wifi_0_radio1.disabled=0"

    uci commit wireless
    echo "  wifi_0_radio0 + wifi_0_radio1: SSID=monsieur-wifi, psk2, enabled"
else
    echo "  wifi_0_radio0/1 already correct, skipping"
fi

# DHCP - only set if currently ignored
dhcp0_ignore=$(uci get "dhcp.dhcp_net_0.ignore" 2>/dev/null)
if [ "$dhcp0_ignore" != "0" ]; then
    uci set "dhcp.dhcp_net_0.ignore=0"
    uci set "dhcp.dhcp_net_0.start=100"
    uci set "dhcp.dhcp_net_0.limit=100"
    uci set "dhcp.dhcp_net_0.leasetime=12h"
    uci commit dhcp
    echo "  dhcp_net_0 enabled (range 172.16.10.100-199)"
else
    echo "  dhcp_net_0 already enabled, skipping"
fi

# Chilli - stays disabled (password network, no captive portal)
chilli0_dis=$(uci get "chilli.chilli_0.disabled" 2>/dev/null)
if [ "$chilli0_dis" != "1" ]; then
    uci set "chilli.chilli_0.disabled=1"
    uci commit chilli
    echo "  chilli_0 disabled (not a captive portal network)"
else
    echo "  chilli_0 already disabled, skipping"
fi

# ---------------------------------------------------------------------------
# 11. Add net_0 to the lan firewall zone so dnsmasq serves it
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 11: Add net_0 to lan firewall zone ---"

# Find the lan zone index
lan_zone_idx=""
idx=0
while true; do
    zone_name=$(uci get "firewall.@zone[$idx].name" 2>/dev/null) || break
    if [ "$zone_name" = "lan" ]; then
        lan_zone_idx=$idx
        break
    fi
    idx=$((idx + 1))
done

if [ -z "$lan_zone_idx" ]; then
    echo "  WARNING: No 'lan' firewall zone found. Creating one."
    uci add firewall zone
    uci set "firewall.@zone[-1].name=lan"
    uci set "firewall.@zone[-1].input=ACCEPT"
    uci set "firewall.@zone[-1].output=ACCEPT"
    uci set "firewall.@zone[-1].forward=ACCEPT"
    uci add_list "firewall.@zone[-1].network=net_0"
    echo "  Created lan zone with net_0"
else
    # Check if net_0 is already in the zone network list
    already_present=0
    for existing_net in $(uci get "firewall.@zone[$lan_zone_idx].network" 2>/dev/null); do
        if [ "$existing_net" = "net_0" ]; then
            already_present=1
            break
        fi
    done
    if [ "$already_present" -eq 0 ]; then
        uci add_list "firewall.@zone[$lan_zone_idx].network=net_0"
        echo "  Added net_0 to firewall zone 'lan' (index $lan_zone_idx)"
    else
        echo "  net_0 already in firewall zone 'lan', skipping"
    fi
fi

uci commit firewall
echo "  Firewall committed."

# ---------------------------------------------------------------------------
# 12. Reload network, wireless, DHCP and firewall
#     Only runs if this script actually made changes (early-exit at Step 0
#     means we only reach here when something was missing/changed).
# ---------------------------------------------------------------------------
echo ""
echo "--- Step 12: Reload services ---"

echo "  Restarting network (brings up br-lan.10..17 and net_0..7)..."
service network restart
echo "  Waiting 10s for bridge VLANs to come up..."
sleep 10

echo "  Reloading wireless (activates wifi_0_radio0/1)..."
wifi reload

echo "  Restarting dnsmasq (activates dhcp_net_0)..."
service dnsmasq restart

echo "  Reloading firewall..."
service firewall reload

echo "  Services reloaded."

# ---------------------------------------------------------------------------
# 13. Summary
# ---------------------------------------------------------------------------
echo ""
echo "========================================="
echo "Bootstrap complete."
echo "========================================="
echo ""
echo "  Legacy ifaces disabled: default_radio0/1, captive_radio0/1"
echo "  net_0 added to firewall lan zone"
echo "  Network / wireless / dnsmasq / firewall reloaded"
echo "  Slot 0 : net_0 | wifi_0_radio0 + radio1 | dhcp_net_0 | chilli_0  | VLAN 10 | ACTIVE"
slot=1
while [ "$slot" -le 7 ]; do
    vlan=$((10 + slot))
    echo "  Slot $slot : net_$slot | wifi_${slot}_radio0 + radio1 | dhcp_net_$slot | chilli_$slot | VLAN $vlan | disabled"
    slot=$((slot + 1))
done
echo ""
echo "  Slot 0 SSID   : monsieur-wifi"
echo "  Slot 0 encrypt: psk2"
echo "  Slot 0 key    : abcd1234"
echo ""
echo "To verify:"
echo "  uci show network | grep -e net_ -e bridge-vlan"
echo "  uci show wireless | grep wifi_"
echo "  uci show dhcp | grep dhcp_net"
echo "  uci show chilli"
echo "  ip addr show br-lan.10   # should show 172.16.10.1/24"
echo "  ip route | grep 172.16   # should show 8 /24 routes"
echo ""
echo "Run update-v2.sh to reconfigure from the API."
echo ""
