#!/bin/sh
#
# update-v2.sh — Multi-network device configuration sync
# Runs on OpenWrt 24 / BusyBox ash (POSIX sh only, no bash-isms)
#
# Supports 0-8 networks per slot from the API networks[] array.
# Network types: captive_portal, password, open
#
# Slot naming:
#   UCI Network:      net_0 .. net_7
#   UCI Wireless 2G:  wifi_0_radio0 .. wifi_7_radio0
#   UCI Wireless 5G:  wifi_0_radio1 .. wifi_7_radio1
#   UCI DHCP:         dhcp_net_0 .. dhcp_net_7
#   UCI Chilli:       chilli_0 .. chilli_7  (named sections in /etc/config/chilli)
#   Bridge VLAN:      br-lan.10 .. br-lan.17  (slot N → VLAN 10+N)
#

key=$(uci get citypassenger.@device[0].key)
secret=$(uci get citypassenger.@device[0].secret)
api_domain=$(uci get citypassenger.@device[0].api_domain)
api="https://$api_domain/api/devices/$key/$secret/v2-settings"
response=$(curl -fsSL "$api")
echo "$api"
echo "$response"

# =============================================================================
# HELPER UTILITIES
# =============================================================================

# Convert netmask dotted-decimal to CIDR prefix length
netmask_to_cidr() {
    local mask="$1"
    case "$mask" in
        "255.255.255.252") echo "30" ;;
        "255.255.255.248") echo "29" ;;
        "255.255.255.240") echo "28" ;;
        "255.255.255.224") echo "27" ;;
        "255.255.255.192") echo "26" ;;
        "255.255.255.128") echo "25" ;;
        "255.255.255.0")   echo "24" ;;
        "255.255.0.0")     echo "16" ;;
        "255.0.0.0")       echo "8"  ;;
        *)                 echo "24" ;;
    esac
}

# Validate dotted-decimal IP address
validate_ip() {
    local ip="$1"
    echo "$ip" | grep -qE '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || return 1
    return 0
}

# Validate numeric VLAN ID (1-4094)
validate_vlan_id() {
    local vlan_id="$1"
    if [ -z "$vlan_id" ] || [ "$vlan_id" = "null" ]; then
        return 1
    fi
    echo "$vlan_id" | grep -qE '^[0-9]+$' || return 1
    if [ "$vlan_id" -ge 1 ] && [ "$vlan_id" -le 4094 ]; then
        return 0
    fi
    return 1
}

# Validate numeric octet (1-254)
validate_octet() {
    local val="$1"
    echo "$val" | grep -qE '^[0-9]+$' || return 1
    if [ "$val" -ge 1 ] && [ "$val" -le 254 ]; then
        return 0
    fi
    return 1
}

# Convert channel width + band to OpenWrt htmode
get_htmode() {
    local band="$1"
    local width="$2"
    if [ "$width" = "20" ]; then
        echo "HE20"
    elif [ "$width" = "40" ]; then
        echo "HE40"
    elif [ "$width" = "80" ] && [ "$band" = "5g" ]; then
        echo "HE80"
    elif [ "$width" = "160" ] && [ "$band" = "5g" ]; then
        echo "HE160"
    else
        if [ "$band" = "2g" ]; then
            echo "HE40"
        else
            echo "HE80"
        fi
    fi
}

# =============================================================================
# BRIDGE / VLAN HELPERS
# =============================================================================

# Return the dedicated UAM listen IP for a captive portal slot.
# Slot N → 10.1(N+1)1.0.1  (slot 0 → 10.101.0.1, slot 1 → 10.102.0.1, …)
get_uamlisten_for_slot() {
    local slot="$1"
    local octet=$((slot + 1))
    echo "10.1${octet}1.0.1"
}

# Detect available physical LAN ports (excludes WAN and wireless)
get_device_ports() {
    local ports=""
    for port in lan1 lan2 lan3 lan4; do
        if [ -e "/sys/class/net/$port" ]; then
            ports="$ports $port"
        fi
    done
    if [ -z "$ports" ]; then
        for port in eth1 eth2 eth3 eth4; do
            if [ -e "/sys/class/net/$port" ]; then
                ports="$ports $port"
            fi
        done
    fi
    if [ -z "$ports" ] && [ -e "/sys/class/net/lan" ]; then
        ports="lan"
    fi
    if [ -z "$ports" ]; then
        for iface in /sys/class/net/*; do
            local port
            port=$(basename "$iface")
            if [ "$port" != "eth0" ] && ! echo "$port" | grep -qE '^(wan|wlan|wifi|lo|br)'; then
                if [ -e "/sys/class/net/$port/operstate" ]; then
                    ports="$ports $port"
                fi
            fi
        done
    fi
    echo "$ports"
}

# Ensure br-lan device UCI section exists
ensure_br_lan_device() {
    local brlan_exists
    brlan_exists=$(uci show network 2>/dev/null | grep "device.*name='br-lan'" | head -1)
    if [ -z "$brlan_exists" ]; then
        echo "Creating br-lan device configuration"
        uci add network device
        uci set "network.@device[-1].name=br-lan"
        uci set "network.@device[-1].type=bridge"
        local ports
        ports=$(get_device_ports)
        for port in $ports; do
            uci add_list "network.@device[-1].ports=$port"
        done
    fi
}

# Remove all bridge-vlan UCI sections
cleanup_existing_vlans() {
    echo "Cleaning up existing VLAN configurations..."
    local count=0
    while uci delete network.@bridge-vlan[0] 2>/dev/null; do
        count=$((count + 1))
    done
    echo "Removed $count bridge-vlan sections"
}

# Set vlan_filtering on br-lan device section
configure_vlan_filtering() {
    local enabled="$1"
    ensure_br_lan_device
    local brlan_section
    brlan_section=$(uci show network 2>/dev/null | grep "device.*name='br-lan'" | cut -d'=' -f1 | cut -d'.' -f2 | head -1)
    if [ -n "$brlan_section" ]; then
        if [ "$enabled" = "true" ]; then
            uci set "network.$brlan_section.vlan_filtering=1"
        else
            uci set "network.$brlan_section.vlan_filtering=0"
        fi
    else
        echo "ERROR: br-lan device section not found"
        return 1
    fi
}

# Add a bridge-vlan UCI section for a given VLAN ID and tagging mode
# untagged: "true" → ports get :u* (PVID untagged), "false" → ports get :t (tagged)
add_bridge_vlan() {
    local vlan_id="$1"
    local untagged="$2"
    if ! validate_vlan_id "$vlan_id"; then
        echo "ERROR: Invalid VLAN ID $vlan_id"
        return 1
    fi
    uci add network bridge-vlan
    uci set "network.@bridge-vlan[-1].device=br-lan"
    uci set "network.@bridge-vlan[-1].vlan=$vlan_id"
    local ports
    ports=$(get_device_ports)
    for port in $ports; do
        if [ "$untagged" = "true" ]; then
            uci add_list "network.@bridge-vlan[-1].ports=$port:u*"
        else
            uci add_list "network.@bridge-vlan[-1].ports=$port:t"
        fi
    done
}

# Ensure bridge comes up with correct IP after network restart
ensure_bridge_configuration() {
    echo "Verifying bridge interfaces post-restart..."
    sleep 3
    local lan_ip lan_netmask
    lan_ip=$(uci get network.lan.ipaddr 2>/dev/null || echo "")
    lan_netmask=$(uci get network.lan.netmask 2>/dev/null || echo "")
    if [ -n "$lan_ip" ] && ip link show br-lan >/dev/null 2>&1; then
        local br_state current_ip
        br_state=$(ip link show br-lan | grep "state" | awk '{print $9}')
        current_ip=$(ip addr show br-lan | grep "inet " | awk '{print $2}' | cut -d'/' -f1)
        if [ "$br_state" = "DOWN" ]; then
            ip link set br-lan up
            sleep 1
        fi
        if [ -n "$lan_ip" ] && [ "$current_ip" != "$lan_ip" ]; then
            ip addr flush dev br-lan 2>/dev/null || true
            local cidr
            cidr=$(netmask_to_cidr "$lan_netmask")
            ip addr add "${lan_ip}/${cidr}" dev br-lan
            echo "br-lan IP set: ${lan_ip}/${cidr}"
        fi
    fi
    echo "Bridge check complete"
}

# =============================================================================
# SLOT BOOTSTRAP
# Ensure all 8 slots have their UCI sections in a disabled state.
# Safe to run on every boot — sections are only created if missing.
# =============================================================================

ensure_slot_exists() {
    local slot="$1"
    local vlan_id=$((10 + slot))

    # --- network section ---
    local net_name="net_${slot}"
    if ! uci get "network.${net_name}" >/dev/null 2>&1; then
        echo "Bootstrapping network section: $net_name"
        uci set "network.${net_name}=interface"
        uci set "network.${net_name}.proto=static"
        uci set "network.${net_name}.device=br-lan.${vlan_id}"
        uci set "network.${net_name}.ipaddr=172.16.${vlan_id}.1"
        uci set "network.${net_name}.netmask=255.255.255.0"
    fi

    # --- wireless 2.4GHz ---
    local wifi_2g="wifi_${slot}_radio0"
    if ! uci get "wireless.${wifi_2g}" >/dev/null 2>&1; then
        echo "Bootstrapping wireless section: $wifi_2g"
        uci set "wireless.${wifi_2g}=wifi-iface"
        uci set "wireless.${wifi_2g}.device=radio0"
        uci set "wireless.${wifi_2g}.network=${net_name}"
        uci set "wireless.${wifi_2g}.mode=ap"
        uci set "wireless.${wifi_2g}.ssid=disabled_${slot}"
        uci set "wireless.${wifi_2g}.encryption=none"
        uci set "wireless.${wifi_2g}.disabled=1"
    fi

    # --- wireless 5GHz ---
    local wifi_5g="wifi_${slot}_radio1"
    if ! uci get "wireless.${wifi_5g}" >/dev/null 2>&1; then
        echo "Bootstrapping wireless section: $wifi_5g"
        uci set "wireless.${wifi_5g}=wifi-iface"
        uci set "wireless.${wifi_5g}.device=radio1"
        uci set "wireless.${wifi_5g}.network=${net_name}"
        uci set "wireless.${wifi_5g}.mode=ap"
        uci set "wireless.${wifi_5g}.ssid=disabled_${slot}"
        uci set "wireless.${wifi_5g}.encryption=none"
        uci set "wireless.${wifi_5g}.disabled=1"
    fi

    # --- DHCP section ---
    local dhcp_name="dhcp_net_${slot}"
    if ! uci get "dhcp.${dhcp_name}" >/dev/null 2>&1; then
        echo "Bootstrapping DHCP section: $dhcp_name"
        uci set "dhcp.${dhcp_name}=dhcp"
        uci set "dhcp.${dhcp_name}.interface=${net_name}"
        uci set "dhcp.${dhcp_name}.start=100"
        uci set "dhcp.${dhcp_name}.limit=100"
        uci set "dhcp.${dhcp_name}.leasetime=12h"
        uci set "dhcp.${dhcp_name}.ignore=1"
    fi

    # --- Chilli section ---
    local chilli_name="chilli_${slot}"
    if ! uci get "chilli.${chilli_name}" >/dev/null 2>&1; then
        echo "Bootstrapping chilli section: $chilli_name"
        uci set "chilli.${chilli_name}=chilli"
        uci set "chilli.${chilli_name}.disabled=1"
        uci set "chilli.${chilli_name}.tundev=tun${slot}"
        uci set "chilli.${chilli_name}.dhcpif=br-lan.${vlan_id}"
        local _cnet_ip
        _cnet_ip=$((100 + slot))
        uci set "chilli.${chilli_name}.net=172.16.${_cnet_ip}.0/24"
        uci set "chilli.${chilli_name}.dynip=172.16.${_cnet_ip}.0/24"
        uci set "chilli.${chilli_name}.dhcplisten=172.16.${_cnet_ip}.1"
        uci set "chilli.${chilli_name}.dns1=8.8.8.8"
        uci set "chilli.${chilli_name}.dns2=8.8.4.4"
        uci set "chilli.${chilli_name}.ipup=/etc/chilli/up.sh"
        uci set "chilli.${chilli_name}.ipdown=/etc/chilli/down.sh"
        uci set "chilli.${chilli_name}.conup=/etc/chilli/conup.sh"
        uci set "chilli.${chilli_name}.wwwdir=/etc/chilli/www"
        uci set "chilli.${chilli_name}.wwwbin=/etc/chilli/wwwsh"
        uci set "chilli.${chilli_name}.kname=${chilli_name}"
        uci set "chilli.${chilli_name}.uamaliasname=${chilli_name}"
    fi
}

# Disable all resources for a slot (called before configuring active slots)
disable_slot() {
    local slot="$1"
    local wifi_2g="wifi_${slot}_radio0"
    local wifi_5g="wifi_${slot}_radio1"
    local dhcp_name="dhcp_net_${slot}"
    local chilli_name="chilli_${slot}"

    uci set "wireless.${wifi_2g}.disabled=1" 2>/dev/null || true
    uci set "wireless.${wifi_5g}.disabled=1" 2>/dev/null || true
    uci set "dhcp.${dhcp_name}.ignore=1" 2>/dev/null || true
    uci set "chilli.${chilli_name}.disabled=1" 2>/dev/null || true
}

# =============================================================================
# VLAN SETUP FOR ALL 8 SLOTS
# Always uses VLANs 10-17 (slot N → VLAN 10+N).
# If API provides a vlan_id for a network it overrides for that slot's device
# assignment, but the bridge-vlan pool is always 10-17 for port isolation.
# =============================================================================

configure_all_vlans() {
    local vlan_enabled="$1"
    # Space-separated list of "slot:tagging" for active slots
    local slot_tagging_list="$2"

    echo "Configuring VLAN bridge for all slots..."
    echo "  vlan_enabled=$vlan_enabled"

    # Always enable vlan_filtering for network isolation
    configure_vlan_filtering "true"

    # Clean and rebuild bridge-vlan sections for slots 0-7
    cleanup_existing_vlans

    for slot in 0 1 2 3 4 5 6 7; do
        local vlan_id=$((10 + slot))
        # Find tagging for this slot from the list ("disabled" = untagged)
        local tagging="disabled"
        for entry in $slot_tagging_list; do
            local entry_slot entry_tag
            entry_slot=$(echo "$entry" | cut -d: -f1)
            entry_tag=$(echo "$entry" | cut -d: -f2)
            if [ "$entry_slot" = "$slot" ]; then
                tagging="$entry_tag"
                break
            fi
        done

        # Normalize tagging value
        local untagged="false"
        if [ "$tagging" = "disabled" ] || [ "$tagging" = "untagged" ]; then
            untagged="true"
        fi

        add_bridge_vlan "$vlan_id" "$untagged"
        echo "  VLAN $vlan_id (slot $slot): untagged=$untagged"
    done
}

# =============================================================================
# CONFIGURE A SINGLE SLOT
# =============================================================================

configure_slot() {
    local slot="$1"
    local net_json="$2"   # raw JSON object for this network, or "" if unused

    local net_name="net_${slot}"
    local wifi_2g="wifi_${slot}_radio0"
    local wifi_5g="wifi_${slot}_radio1"
    local dhcp_name="dhcp_net_${slot}"
    local chilli_name="chilli_${slot}"
    local default_vlan=$((10 + slot))

    if [ -z "$net_json" ] || [ "$net_json" = "null" ]; then
        disable_slot "$slot"
        return
    fi

    # Parse network fields
    local net_type net_enabled net_ssid net_visible net_password net_security
    local net_vlan_id net_vlan_tagging net_ip_mode net_ip net_netmask
    local net_dns1 net_dns2 net_dhcp_enabled net_dhcp_start net_dhcp_end
    local net_mac_filter_mode net_mac_filter_list
    local net_id

    net_type=$(echo "$net_json" | jq -r '.type // "open"')
    net_enabled=$(echo "$net_json" | jq -r '.enabled // true')
    net_ssid=$(echo "$net_json" | jq -r '.ssid // ""')
    net_visible=$(echo "$net_json" | jq -r '.visible // true')
    net_password=$(echo "$net_json" | jq -r '.password // ""')
    net_security=$(echo "$net_json" | jq -r '.security // "wpa2-psk"')
    net_vlan_id=$(echo "$net_json" | jq -r '.vlan_id // "null"')
    net_vlan_tagging=$(echo "$net_json" | jq -r '.vlan_tagging // "disabled"')
    net_ip_mode=$(echo "$net_json" | jq -r '.ip_mode // "static"')
    net_ip=$(echo "$net_json" | jq -r '.ip_address // ""')
    net_netmask=$(echo "$net_json" | jq -r '.netmask // "255.255.255.0"')
    net_dns1=$(echo "$net_json" | jq -r '.dns1 // "8.8.8.8"')
    net_dns2=$(echo "$net_json" | jq -r '.dns2 // "8.8.4.4"')
    net_dhcp_enabled=$(echo "$net_json" | jq -r '.dhcp_enabled // true')
    net_dhcp_start=$(echo "$net_json" | jq -r '.dhcp_start // ""')
    net_dhcp_end=$(echo "$net_json" | jq -r '.dhcp_end // ""')
    net_mac_filter_mode=$(echo "$net_json" | jq -r '.mac_filter_mode // "allow-all"')
    net_mac_filter_list=$(echo "$net_json" | jq -r '.mac_filter_list // "null"')
    net_id=$(echo "$net_json" | jq -r '.id // ""')

    # If network is explicitly disabled, shut down slot
    if [ "$net_enabled" = "false" ]; then
        echo "Slot $slot: network disabled, skipping"
        disable_slot "$slot"
        return
    fi

    # Validate SSID
    if [ -z "$net_ssid" ] || [ "$net_ssid" = "null" ]; then
        echo "Slot $slot: empty SSID, disabling slot"
        disable_slot "$slot"
        return
    fi

    echo "Configuring slot $slot: type=$net_type ssid=$net_ssid"

    # Determine device (use API vlan_id if valid, otherwise slot default)
    local effective_vlan="$default_vlan"
    if validate_vlan_id "$net_vlan_id"; then
        effective_vlan="$net_vlan_id"
    fi
    local device="br-lan.${effective_vlan}"

    # --- Network interface ---
    uci set "network.${net_name}.proto=static"
    uci set "network.${net_name}.device=${device}"

    if [ "$net_ip_mode" = "static" ] || [ "$net_ip_mode" = "STATIC" ]; then
        if validate_ip "$net_ip" && [ -n "$net_netmask" ] && [ "$net_netmask" != "null" ]; then
            uci set "network.${net_name}.ipaddr=${net_ip}"
            uci set "network.${net_name}.netmask=${net_netmask}"
        else
            echo "Slot $slot: invalid IP/netmask, using defaults"
            uci set "network.${net_name}.ipaddr=172.16.${default_vlan}.1"
            uci set "network.${net_name}.netmask=255.255.255.0"
        fi
    else
        uci set "network.${net_name}.proto=dhcp"
    fi

    # DNS for the network interface
    uci delete "network.${net_name}.dns" 2>/dev/null || true
    if [ -n "$net_dns1" ] && [ "$net_dns1" != "null" ] && validate_ip "$net_dns1"; then
        uci add_list "network.${net_name}.dns=${net_dns1}"
    fi
    if [ -n "$net_dns2" ] && [ "$net_dns2" != "null" ] && validate_ip "$net_dns2"; then
        uci add_list "network.${net_name}.dns=${net_dns2}"
    fi

    # --- Wireless interfaces ---
    local hidden="0"
    if [ "$net_visible" = "false" ] || [ "$net_visible" = "0" ]; then
        hidden="1"
    fi

    local encryption="none"
    local wifi_key=""

    if [ "$net_type" = "password" ]; then
        # Password-protected WiFi
        if [ -n "$net_password" ] && [ "$net_password" != "null" ] && [ "${#net_password}" -ge 8 ]; then
            encryption="psk2"
            wifi_key="$net_password"
        else
            echo "Slot $slot: password type but no valid password set, broadcasting open"
            encryption="none"
        fi
    fi
    # captive_portal and open both use encryption=none (Chilli intercepts for captive)

    uci set "wireless.${wifi_2g}.ssid=${net_ssid}"
    uci set "wireless.${wifi_2g}.hidden=${hidden}"
    uci set "wireless.${wifi_2g}.encryption=${encryption}"
    uci set "wireless.${wifi_2g}.network=${net_name}"
    uci set "wireless.${wifi_2g}.disabled=0"

    uci set "wireless.${wifi_5g}.ssid=${net_ssid}"
    uci set "wireless.${wifi_5g}.hidden=${hidden}"
    uci set "wireless.${wifi_5g}.encryption=${encryption}"
    uci set "wireless.${wifi_5g}.network=${net_name}"
    uci set "wireless.${wifi_5g}.disabled=0"

    if [ "$encryption" = "psk2" ] && [ -n "$wifi_key" ]; then
        uci set "wireless.${wifi_2g}.key=${wifi_key}"
        uci set "wireless.${wifi_5g}.key=${wifi_key}"
    else
        uci delete "wireless.${wifi_2g}.key" 2>/dev/null || true
        uci delete "wireless.${wifi_5g}.key" 2>/dev/null || true
    fi

    # --- MAC filtering (password networks only) ---
    configure_mac_filter "$slot" "$net_type" "$net_mac_filter_mode" "$net_mac_filter_list"

    # --- DHCP and Chilli ---
    if [ "$net_type" = "captive_portal" ]; then
        # Chilli runs its own built-in DHCP server — disable dnsmasq for this interface
        configure_slot_dhcp "$slot" "false" "" ""
        configure_slot_chilli "$slot" "$net_json" "$effective_vlan" "$net_ip"
        uci set "chilli.${chilli_name}.disabled=0"
    else
        configure_slot_dhcp "$slot" "$net_dhcp_enabled" "$net_dhcp_start" "$net_dhcp_end"
        uci set "chilli.${chilli_name}.disabled=1"
    fi
}

# Configure DHCP for a slot
configure_slot_dhcp() {
    local slot="$1"
    local dhcp_enabled="$2"
    local dhcp_start_full="$3"
    local dhcp_end_full="$4"
    local dhcp_name="dhcp_net_${slot}"
    local net_name="net_${slot}"

    uci set "dhcp.${dhcp_name}.interface=${net_name}"

    if [ "$dhcp_enabled" = "false" ] || [ "$dhcp_enabled" = "0" ]; then
        uci set "dhcp.${dhcp_name}.ignore=1"
        return
    fi

    uci set "dhcp.${dhcp_name}.ignore=0"
    uci set "dhcp.${dhcp_name}.leasetime=12h"

    # Extract last octets for dnsmasq start/limit
    local start_octet end_octet
    start_octet=$(echo "$dhcp_start_full" | awk -F'.' '{print $4}')
    end_octet=$(echo "$dhcp_end_full" | awk -F'.' '{print $4}')

    if validate_octet "$start_octet" && validate_octet "$end_octet" && [ "$end_octet" -ge "$start_octet" ]; then
        local limit
        limit=$((end_octet - start_octet + 1))
        uci set "dhcp.${dhcp_name}.start=${start_octet}"
        uci set "dhcp.${dhcp_name}.limit=${limit}"
    else
        echo "Slot $slot: DHCP range invalid ($dhcp_start_full - $dhcp_end_full), using defaults"
        uci set "dhcp.${dhcp_name}.start=100"
        uci set "dhcp.${dhcp_name}.limit=100"
    fi
}

# Configure Chilli for a captive_portal slot
configure_slot_chilli() {
    local slot="$1"
    local net_json="$2"
    local vlan_id="$3"
    local portal_ip="$4"
    local chilli_name="chilli_${slot}"

    # Derive the /24 network address for chilli net= field
    local ip_base chilli_net
    ip_base=$(echo "$portal_ip" | cut -d. -f1-3)
    chilli_net="${ip_base}.0/24"

    # Dedicated UAM listen IP — separate from the client gateway (dhcplisten)
    local uam_ip
    uam_ip=$(get_uamlisten_for_slot "$slot")

    uci set "chilli.${chilli_name}.tundev=tun${slot}"
    uci set "chilli.${chilli_name}.dhcpif=br-lan.${vlan_id}"
    uci set "chilli.${chilli_name}.net=${chilli_net}"
    uci set "chilli.${chilli_name}.dynip=${chilli_net}"
    uci set "chilli.${chilli_name}.dhcplisten=${portal_ip}"
    uci set "chilli.${chilli_name}.uamlisten=${uam_ip}"
    uci set "chilli.${chilli_name}.dns1=8.8.8.8"
    uci set "chilli.${chilli_name}.dns2=8.8.4.4"

    # RADIUS settings (from guest_settings / radius_settings embedded in network)
    local radius_ip radius_secret
    radius_ip=$(echo "$net_json" | jq -r '.radius_settings.radius_ip // ""')
    radius_secret=$(echo "$net_json" | jq -r '.radius_settings.radius_secret // ""')

    if [ -n "$radius_ip" ] && [ "$radius_ip" != "null" ]; then
        uci set "chilli.${chilli_name}.radiusserver1=${radius_ip}"
        uci set "chilli.${chilli_name}.radiusserver2=${radius_ip}"
    fi
    if [ -n "$radius_secret" ] && [ "$radius_secret" != "null" ]; then
        uci set "chilli.${chilli_name}.radiussecret=${radius_secret}"
    fi

    # UAM / guest portal settings
    local login_url whitelist_servers whitelist_domains
    login_url=$(echo "$net_json" | jq -r '.guest_settings.login_url // ""')
    whitelist_servers=$(echo "$net_json" | jq -r '.guest_settings.whitelist_servers // ""')
    whitelist_domains=$(echo "$net_json" | jq -r '.guest_settings.whitelist_domains // ""')

    if [ -n "$login_url" ] && [ "$login_url" != "null" ]; then
        uci set "chilli.${chilli_name}.uamserver=${login_url}"
    fi
    if [ -n "$whitelist_servers" ] && [ "$whitelist_servers" != "null" ]; then
        uci set "chilli.${chilli_name}.uamallowed=${whitelist_servers}"
    fi
    if [ -n "$whitelist_domains" ] && [ "$whitelist_domains" != "null" ]; then
        uci set "chilli.${chilli_name}.uamdomain=${whitelist_domains}"
    fi

    # NAS ID from network id
    local network_id
    network_id=$(echo "$net_json" | jq -r '.id // ""')
    if [ -n "$network_id" ] && [ "$network_id" != "null" ]; then
        uci set "chilli.${chilli_name}.radiusnasid=${network_id}"
    fi

    # Static paths
    uci set "chilli.${chilli_name}.ipup=/etc/chilli/up.sh"
    uci set "chilli.${chilli_name}.ipdown=/etc/chilli/down.sh"
    uci set "chilli.${chilli_name}.conup=/etc/chilli/conup.sh"
    uci set "chilli.${chilli_name}.wwwdir=/etc/chilli/www"
    uci set "chilli.${chilli_name}.wwwbin=/etc/chilli/wwwsh"
    uci set "chilli.${chilli_name}.kname=${chilli_name}"
    uci set "chilli.${chilli_name}.uamaliasname=${chilli_name}"
}

# Configure MAC filtering for a slot's wireless interfaces
configure_mac_filter() {
    local slot="$1"
    local net_type="$2"
    local mac_filter_mode="$3"
    local mac_filter_list_json="$4"
    local wifi_2g="wifi_${slot}_radio0"
    local wifi_5g="wifi_${slot}_radio1"

    # Only apply blacklist MAC filtering on password networks
    if [ "$net_type" != "password" ]; then
        uci set "wireless.${wifi_2g}.macfilter=disable" 2>/dev/null || true
        uci delete "wireless.${wifi_2g}.maclist" 2>/dev/null || true
        uci set "wireless.${wifi_5g}.macfilter=disable" 2>/dev/null || true
        uci delete "wireless.${wifi_5g}.maclist" 2>/dev/null || true
        return
    fi

    if [ -z "$mac_filter_list_json" ] || [ "$mac_filter_list_json" = "null" ] || [ "$mac_filter_list_json" = "[]" ]; then
        uci set "wireless.${wifi_2g}.macfilter=disable"
        uci delete "wireless.${wifi_2g}.maclist" 2>/dev/null || true
        uci set "wireless.${wifi_5g}.macfilter=disable"
        uci delete "wireless.${wifi_5g}.maclist" 2>/dev/null || true
        return
    fi

    local blacklist_macs
    blacklist_macs=$(echo "$mac_filter_list_json" | jq -r '.[] | select(.type == "blacklist") | .mac' | tr '\n' ' ' | sed 's/^ *//;s/ *$//')

    if [ -n "$blacklist_macs" ]; then
        uci set "wireless.${wifi_2g}.macfilter=deny"
        uci delete "wireless.${wifi_2g}.maclist" 2>/dev/null || true
        uci set "wireless.${wifi_5g}.macfilter=deny"
        uci delete "wireless.${wifi_5g}.maclist" 2>/dev/null || true
        for mac in $blacklist_macs; do
            uci add_list "wireless.${wifi_2g}.maclist=${mac}"
            uci add_list "wireless.${wifi_5g}.maclist=${mac}"
        done
    else
        uci set "wireless.${wifi_2g}.macfilter=disable"
        uci delete "wireless.${wifi_2g}.maclist" 2>/dev/null || true
        uci set "wireless.${wifi_5g}.macfilter=disable"
        uci delete "wireless.${wifi_5g}.maclist" 2>/dev/null || true
    fi
}

# =============================================================================
# FIREWALL ZONE MANAGEMENT
# Captive portal slots get their own isolated zone (chilli manages per-client
# iptables rules). Non-captive slots are added to the shared lan zone so
# dnsmasq can serve them.
# =============================================================================

configure_firewall_zones() {
    # Arguments:
    #   $1 — space-separated "slot:vlan" pairs for active captive portal slots
    #   $2 — space-separated slot numbers for active non-captive slots
    local captive_list="$1"
    local noncaptive_list="$2"

    # --- Find the lan zone index ---
    local lan_zone_idx=""
    local idx=0
    while true; do
        local zname
        zname=$(uci get "firewall.@zone[$idx].name" 2>/dev/null) || break
        if [ "$zname" = "lan" ]; then
            lan_zone_idx=$idx
            break
        fi
        idx=$((idx + 1))
    done

    # --- Non-captive slots: add net_N to the lan zone ---
    if [ -n "$lan_zone_idx" ]; then
        for slot in $noncaptive_list; do
            local net_name="net_${slot}"
            local already=0
            for n in $(uci get "firewall.@zone[$lan_zone_idx].network" 2>/dev/null); do
                [ "$n" = "$net_name" ] && already=1
            done
            if [ "$already" -eq 0 ]; then
                uci add_list "firewall.@zone[$lan_zone_idx].network=$net_name"
                echo "  Added $net_name to firewall lan zone"
            fi
        done
    fi

    # --- Captive portal slots: dedicated zone per slot ---
    for entry in $captive_list; do
        local slot
        slot=$(echo "$entry" | cut -d: -f1)
        local net_name="net_${slot}"
        local zone_name="cp_net_${slot}"

        # Remove net_N from the lan zone if it was previously there
        if [ -n "$lan_zone_idx" ]; then
            uci del_list "firewall.@zone[$lan_zone_idx].network=$net_name" 2>/dev/null || true
        fi

        # Check if this captive portal zone already exists
        local zone_exists=false
        local zi=0
        while true; do
            local zn
            zn=$(uci get "firewall.@zone[$zi].name" 2>/dev/null) || break
            if [ "$zn" = "$zone_name" ]; then
                zone_exists=true
                break
            fi
            zi=$((zi + 1))
        done

        if [ "$zone_exists" = false ]; then
            echo "  Creating firewall zone $zone_name for $net_name"
            uci add firewall zone
            uci set "firewall.@zone[-1].name=$zone_name"
            uci set "firewall.@zone[-1].input=ACCEPT"
            uci set "firewall.@zone[-1].output=ACCEPT"
            uci set "firewall.@zone[-1].forward=ACCEPT"
            uci add_list "firewall.@zone[-1].network=$net_name"

            # Forwarding rule: captive zone → wan
            uci add firewall forwarding
            uci set "firewall.@forwarding[-1].src=$zone_name"
            uci set "firewall.@forwarding[-1].dest=wan"
            echo "  Created forwarding $zone_name → wan"
        else
            echo "  Firewall zone $zone_name already exists"
        fi
    done

    uci commit firewall
}

# =============================================================================
# CONUP.SH REGENERATION
# Rewrites /etc/chilli/conup.sh so each tunN maps to its br-lan.<vlan>
# and the chilli_users_N tracking file. Only active captive_portal slots
# are mapped; all others fall through to the catch-all logger.
# =============================================================================

regenerate_conup_sh() {
    # Arguments: space-separated list of "slot:vlan_id" for active captive slots
    local captive_slot_vlan_list="$1"
    local conup="/etc/chilli/conup.sh"

    echo "Regenerating $conup..."

    cat > "$conup" << 'CONUP_HEADER'
#!/bin/sh

ip=${FRAMED_IP_ADDRESS}
tun=${DEV}
CONUP_HEADER

    # Build the case statement
    printf 'case $tun in\n' >> "$conup"

    for entry in $captive_slot_vlan_list; do
        local slot vlan_id
        slot=$(echo "$entry" | cut -d: -f1)
        vlan_id=$(echo "$entry" | cut -d: -f2)
        printf '        "tun%s")\n' "$slot" >> "$conup"
        printf '            dev="br-lan.%s"\n' "$vlan_id" >> "$conup"
        printf '            dev_id="%s"\n' "$slot" >> "$conup"
        printf '            ;;\n' >> "$conup"
    done

    cat >> "$conup" << 'CONUP_FOOTER'
        *)
            logger "Unknown TUNTAP device: $tun"
            exit 0
            ;;
esac

up=${WISPR_BANDWIDTH_MAX_UP}
dl=${WISPR_BANDWIDTH_MAX_DOWN}
up_mb=$((up / 1000000))
dl_mb=$((dl / 1000000))
mac=${CALLING_STATION_ID}
cnt="$dev_id$(tc class show dev $dev | wc -l)"

ip_entry=$(uci -c /tmp show chilli_users_$dev_id | grep "$ip" | cut -d'=' -f1 | sed 's/\.[^\.]*$//')
if [ -n "$ip_entry" ]; then
    uci -c /tmp delete "$ip_entry"
    uci -c /tmp commit chilli_users_$dev_id
fi

mac_entry=$(uci -c /tmp show chilli_users_$dev_id | grep "$mac" | cut -d'=' -f1 | sed 's/\.[^\.]*$//')
if [ -n "$mac_entry" ]; then
    uci -c /tmp delete "$mac_entry"
    uci -c /tmp commit chilli_users_$dev_id
fi

while :; do
    id_entry=$(uci -c /tmp show chilli_users_$dev_id | grep "id='$cnt'" | cut -d'=' -f1 | sed 's/\.[^\.]*$//' | head -n 1)
    [ -n "$id_entry" ] || break
    uci -c /tmp delete "$id_entry"
    uci -c /tmp commit chilli_users_$dev_id
done

uci -c /tmp add chilli_users_$dev_id device
uci -c /tmp set chilli_users_$dev_id.@device[-1].id="$cnt"
uci -c /tmp set chilli_users_$dev_id.@device[-1].ip="$ip"
uci -c /tmp set chilli_users_$dev_id.@device[-1].mac="$mac"
uci -c /tmp set chilli_users_$dev_id.@device[-1].max_up="$up_mb"
uci -c /tmp set chilli_users_$dev_id.@device[-1].max_down="$dl_mb"
uci -c /tmp commit chilli_users_$dev_id

if [ "$up" = 0 ] || [ "$dl" = 0 ]; then
    logger "Unlimited bandwidth for $mac IP:$ip"
else
    tc class replace dev $dev parent 1:1 classid 1:1$cnt htb rate ${dl_mb}mbit ceil ${dl_mb}mbit
    tc filter replace dev $dev parent 1:0 protocol ip u32 match ip dst $ip flowid 1:1$cnt
    tc class replace dev ${dev}-ifb parent 1:1 classid 1:1$cnt htb rate ${up_mb}mbit ceil ${up_mb}mbit
    tc filter replace dev ${dev}-ifb parent 1:0 protocol ip u32 match ip src $ip flowid 1:1$cnt
    logger "Bandwidth set: UP=${up_mb}Mb/s DOWN=${dl_mb}Mb/s for $mac IP:$ip"
fi
CONUP_FOOTER

    chmod +x "$conup"
    echo "conup.sh regenerated with captive slots: $captive_slot_vlan_list"
}

# =============================================================================
# BLOCKED DOMAINS MANAGEMENT
# =============================================================================

configure_blocked_domains() {
    local blocked_domains_json="$1"
    # Target IP for blocked domain redirects — first captive portal network IP
    local redirect_ip="$2"

    local has_blocked=false
    local domains_changed=false

    if [ -n "$blocked_domains_json" ] && [ "$blocked_domains_json" != "null" ] && [ "$blocked_domains_json" != "[]" ]; then
        local count
        count=$(echo "$blocked_domains_json" | jq -r 'length')
        if [ "$count" -gt 0 ]; then
            has_blocked=true
        fi
    fi

    # Get currently configured blocked domains pointing to redirect_ip
    local current_blocked=""
    if [ -n "$redirect_ip" ] && [ "$redirect_ip" != "null" ]; then
        local current_list
        current_list=$(uci show dhcp.@dnsmasq[0].address 2>/dev/null | cut -d'=' -f2- | tr -d "'" | tr ' ' '\n')
        for entry in $current_list; do
            if echo "$entry" | grep -q "/${redirect_ip}$"; then
                local domain
                domain=$(echo "$entry" | sed "s|^/||" | sed "s|/${redirect_ip}$||")
                [ -n "$domain" ] && current_blocked="$current_blocked $domain"
            fi
        done
        current_blocked=$(echo "$current_blocked" | sed 's/^ *//;s/ *$//')
    fi

    local current_filter_aaaa new_domains
    current_filter_aaaa=$(uci get dhcp.@dnsmasq[0].filter_aaaa 2>/dev/null || echo "0")

    if [ "$has_blocked" = true ] && [ -n "$redirect_ip" ]; then
        new_domains=$(echo "$blocked_domains_json" | jq -r '.[].domain' | tr '\n' ' ')

        if [ "$current_blocked" != "$new_domains" ]; then
            for domain in $current_blocked; do
                [ -n "$domain" ] && uci del_list dhcp.@dnsmasq[0].address="/$domain/$redirect_ip"
            done
            for domain in $new_domains; do
                [ -n "$domain" ] && uci add_list dhcp.@dnsmasq[0].address="/$domain/$redirect_ip"
            done
            domains_changed=true
        fi

        if [ "$current_filter_aaaa" != "1" ]; then
            uci set dhcp.@dnsmasq[0].filter_aaaa=1
            domains_changed=true
        fi
    else
        # Remove all existing blocked domains
        for domain in $current_blocked; do
            if [ -n "$domain" ] && [ -n "$redirect_ip" ]; then
                uci del_list dhcp.@dnsmasq[0].address="/$domain/$redirect_ip"
                domains_changed=true
            fi
        done

        if [ "$current_filter_aaaa" != "0" ]; then
            uci set dhcp.@dnsmasq[0].filter_aaaa=0
            domains_changed=true
        fi
    fi

    if [ "$domains_changed" = true ]; then
        uci commit dhcp
        /etc/init.d/dnsmasq restart
        echo "DNS/domain config updated"
    fi

    # DNS filtering service
    local dns_filter_svc dns_flag currently_active
    dns_filter_svc="/etc/init.d/dns_filtering"
    dns_flag="/tmp/dns_redirect_enabled"
    currently_active=false
    [ -f "$dns_flag" ] && currently_active=true

    if [ "$has_blocked" = true ] && [ "$currently_active" = false ]; then
        [ -f "$dns_filter_svc" ] && "$dns_filter_svc" start
    elif [ "$has_blocked" = false ] && [ "$currently_active" = true ]; then
        [ -f "$dns_filter_svc" ] && "$dns_filter_svc" stop
    fi

    if [ "$has_blocked" = true ]; then
        [ -f "$dns_filter_svc" ] && "$dns_filter_svc" enable 2>/dev/null
    else
        [ -f "$dns_filter_svc" ] && "$dns_filter_svc" disable 2>/dev/null
    fi
}

# =============================================================================
# RADIO CONFIGURATION
# =============================================================================

configure_radios() {
    local country_code="$1"
    local channel_2g="$2"
    local width_2g="$3"
    local power_2g="$4"
    local channel_5g="$5"
    local width_5g="$6"
    local power_5g="$7"
    local radio_changed=false

    local cur_country_r0 cur_country_r1
    cur_country_r0=$(uci get wireless.radio0.country 2>/dev/null || echo "")
    cur_country_r1=$(uci get wireless.radio1.country 2>/dev/null || echo "")

    if [ -n "$country_code" ] && [ "$country_code" != "null" ]; then
        if [ "$cur_country_r0" != "$country_code" ]; then
            uci set wireless.radio0.country="$country_code"
            radio_changed=true
        fi
        if [ "$cur_country_r1" != "$country_code" ]; then
            uci set wireless.radio1.country="$country_code"
            radio_changed=true
        fi
    fi

    # 2.4GHz
    if [ -n "$channel_2g" ] && [ "$channel_2g" != "null" ]; then
        local cur
        cur=$(uci get wireless.radio0.channel 2>/dev/null || echo "")
        if [ "$cur" != "$channel_2g" ]; then
            uci set wireless.radio0.channel="$channel_2g"
            radio_changed=true
        fi
    fi
    if [ -n "$width_2g" ] && [ "$width_2g" != "null" ]; then
        local htmode cur
        htmode=$(get_htmode "2g" "$width_2g")
        cur=$(uci get wireless.radio0.htmode 2>/dev/null || echo "")
        if [ "$cur" != "$htmode" ]; then
            uci set wireless.radio0.htmode="$htmode"
            radio_changed=true
        fi
    fi
    if [ -n "$power_2g" ] && [ "$power_2g" != "null" ]; then
        local cur
        cur=$(uci get wireless.radio0.txpower 2>/dev/null || echo "")
        if [ "$cur" != "$power_2g" ]; then
            uci set wireless.radio0.txpower="$power_2g"
            radio_changed=true
        fi
    fi

    # 5GHz
    if [ -n "$channel_5g" ] && [ "$channel_5g" != "null" ]; then
        local cur
        cur=$(uci get wireless.radio1.channel 2>/dev/null || echo "")
        if [ "$cur" != "$channel_5g" ]; then
            uci set wireless.radio1.channel="$channel_5g"
            radio_changed=true
        fi
    fi
    if [ -n "$width_5g" ] && [ "$width_5g" != "null" ]; then
        local htmode cur
        htmode=$(get_htmode "5g" "$width_5g")
        cur=$(uci get wireless.radio1.htmode 2>/dev/null || echo "")
        if [ "$cur" != "$htmode" ]; then
            uci set wireless.radio1.htmode="$htmode"
            radio_changed=true
        fi
    fi
    if [ -n "$power_5g" ] && [ "$power_5g" != "null" ]; then
        local cur
        cur=$(uci get wireless.radio1.txpower 2>/dev/null || echo "")
        if [ "$cur" != "$power_5g" ]; then
            uci set wireless.radio1.txpower="$power_5g"
            radio_changed=true
        fi
    fi

    echo "$radio_changed"
}

# =============================================================================
# MAIN
# =============================================================================

echo "=================================="
echo "PRODUCTION MODE: Multi-network update"
echo "=================================="

status=$(echo "$response" | jq -r '.status')

if [ "$status" != "success" ]; then
    echo "ERROR: API returned status '$status', aborting"
    exit 1
fi

# ---- Extract global settings ----
country_code=$(echo "$response" | jq -r '.settings.country_code // "US"')
transmit_power_2g=$(echo "$response" | jq -r '.settings.transmit_power_2g // ""')
transmit_power_5g=$(echo "$response" | jq -r '.settings.transmit_power_5g // ""')
channel_2g=$(echo "$response" | jq -r '.settings.channel_2g // ""')
channel_5g=$(echo "$response" | jq -r '.settings.channel_5g // ""')
channel_width_2g=$(echo "$response" | jq -r '.settings.channel_width_2g // ""')
channel_width_5g=$(echo "$response" | jq -r '.settings.channel_width_5g // ""')
vlan_enabled=$(echo "$response" | jq -r '.settings.vlan_enabled // false')
blocked_domains_json=$(echo "$response" | jq -r '.blocked_domains // "[]"')

network_count=$(echo "$response" | jq -r '.networks | length')
echo "API returned $network_count network(s), vlan_enabled=$vlan_enabled"

# ---- Phase 1: Bootstrap all 8 slots ----
echo "--- Phase 1: Bootstrap slots ---"
for slot in 0 1 2 3 4 5 6 7; do
    ensure_slot_exists "$slot"
done
uci commit network
uci commit wireless
uci commit dhcp
uci commit chilli

# ---- Phase 2: Configure radios ----
echo "--- Phase 2: Radio configuration ---"
radio_changed=$(configure_radios \
    "$country_code" \
    "$channel_2g" "$channel_width_2g" "$transmit_power_2g" \
    "$channel_5g" "$channel_width_5g" "$transmit_power_5g")
echo "radio_changed=$radio_changed"

# ---- Phase 3: VLAN bridge setup ----
echo "--- Phase 3: VLAN bridge setup ---"
# Build slot_tagging_list: "slot:tagging" for all active slots
slot_tagging_list=""
for slot in 0 1 2 3 4 5 6 7; do
    if [ "$slot" -lt "$network_count" ]; then
        tagging=$(echo "$response" | jq -r ".networks[$slot].vlan_tagging // \"disabled\"")
    else
        tagging="disabled"
    fi
    slot_tagging_list="$slot_tagging_list ${slot}:${tagging}"
done
slot_tagging_list=$(echo "$slot_tagging_list" | sed 's/^ *//;s/ *$//')

configure_all_vlans "$vlan_enabled" "$slot_tagging_list"

# ---- Phase 4: Configure each slot ----
echo "--- Phase 4: Configure network slots ---"

# Track captive portal slots for conup.sh regeneration and blocked domain redirect
# Track non-captive active slots for lan zone membership
captive_slot_vlan_list=""
noncaptive_slot_list=""
first_captive_ip=""

for slot in 0 1 2 3 4 5 6 7; do
    if [ "$slot" -lt "$network_count" ]; then
        net_json=$(echo "$response" | jq -c ".networks[$slot]")
        configure_slot "$slot" "$net_json"

        # Track slot type for firewall zone assignment
        net_type=$(echo "$net_json" | jq -r '.type // "open"')
        net_enabled=$(echo "$net_json" | jq -r '.enabled // true')
        if [ "$net_enabled" != "false" ]; then
            if [ "$net_type" = "captive_portal" ]; then
                # Determine effective VLAN for this slot
                local_vlan_id=$(echo "$net_json" | jq -r '.vlan_id // "null"')
                if validate_vlan_id "$local_vlan_id"; then
                    eff_vlan="$local_vlan_id"
                else
                    eff_vlan=$((10 + slot))
                fi
                captive_slot_vlan_list="$captive_slot_vlan_list ${slot}:${eff_vlan}"

                if [ -z "$first_captive_ip" ]; then
                    first_captive_ip=$(echo "$net_json" | jq -r '.ip_address // ""')
                fi
            else
                noncaptive_slot_list="$noncaptive_slot_list $slot"
            fi
        fi
    else
        disable_slot "$slot"
    fi
done

captive_slot_vlan_list=$(echo "$captive_slot_vlan_list" | sed 's/^ *//;s/ *$//')
noncaptive_slot_list=$(echo "$noncaptive_slot_list" | sed 's/^ *//;s/ *$//')
echo "Active captive slots: $captive_slot_vlan_list"
echo "Active non-captive slots: $noncaptive_slot_list"

# ---- Phase 5: Regenerate conup.sh ----
echo "--- Phase 5: Regenerate conup.sh ---"
regenerate_conup_sh "$captive_slot_vlan_list"

# ---- Phase 6: Commit and restart services ----
echo "--- Phase 6: Commit and restart ---"

# Configure firewall zones:
#   - Non-captive slots → added to the lan zone (dnsmasq served)
#   - Captive portal slots → dedicated cp_net_N zone with forwarding to wan
configure_firewall_zones "$captive_slot_vlan_list" "$noncaptive_slot_list"

uci commit wireless
uci commit network
uci commit dhcp
uci commit chilli

# Network restart (always needed for VLAN changes)
echo "Restarting network..."
/etc/init.d/network restart
sleep 8
ensure_bridge_configuration

# Firewall reload (picks up new lan zone members)
echo "Reloading firewall..."
/etc/init.d/firewall reload

# Wireless restart
if [ "$radio_changed" = "true" ]; then
    echo "Radio settings changed, performing full WiFi restart..."
    wifi down
    sleep 3
    wifi up
else
    echo "Performing WiFi reload..."
    wifi reload
fi

# Chilli restart
echo "Restarting chilli..."
/etc/init.d/chilli restart

# dnsmasq restart
echo "Restarting dnsmasq..."
/etc/init.d/dnsmasq restart

# ---- Phase 7: Blocked domains ----
echo "--- Phase 7: Blocked domains ---"
configure_blocked_domains "$blocked_domains_json" "$first_captive_ip"

echo "=================================="
echo "PRODUCTION MODE COMPLETE"
echo "=================================="
