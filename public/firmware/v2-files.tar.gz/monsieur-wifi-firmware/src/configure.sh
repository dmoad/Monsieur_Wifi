#!/bin/sh
# configure.sh — UPGRADE installer.
# Downloaded as part of a firmware tar and run by the upgrade flow in push-heartbeat.sh.
# CWD must be src/ (the directory containing this file inside the extracted tar).
# Target: OpenWrt 24 / BusyBox ash (POSIX sh only, no bash-isms)

set -e

log() { logger -t "configure.sh" "$*"; echo "$*"; }

log "=== CityPassenger Upgrade ==="
log "Running from: $(pwd)"

# ---------------------------------------------------------------------------
# 1. Install /etc/citypassenger/
# ---------------------------------------------------------------------------
log "Installing /etc/citypassenger/..."
rm -rf /etc/citypassenger/
cp -rf etc/citypassenger/ /etc/citypassenger/
chmod +x /etc/citypassenger/*.sh
log "Scripts installed"

# ---------------------------------------------------------------------------
# 2. Install VERSION
# ---------------------------------------------------------------------------
if [ -f "../VERSION.md" ]; then
    cp ../VERSION.md /etc/citypassenger/VERSION
    log "VERSION installed: $(cat ../VERSION.md)"
elif [ -f "VERSION.md" ]; then
    cp VERSION.md /etc/citypassenger/VERSION
    log "VERSION installed: $(cat VERSION.md)"
else
    log "WARNING: VERSION.md not found, skipping"
fi

# ---------------------------------------------------------------------------
# 3. Install /etc/rc.local — upgrade version (model + chilli copy only).
#    Device is already verified; cron handles heartbeat. No verify loop needed.
# ---------------------------------------------------------------------------
log "Installing /etc/rc.local (post-verify boot script)..."
cp etc/citypassenger/rc.local /etc/rc.local
chmod +x /etc/rc.local
log "/etc/rc.local installed"
echo "W635ai" > /tmp/sysinfo/model

# ---------------------------------------------------------------------------
# 4. Merge /etc/config/citypassenger — preserve runtime credentials
#    Only api_domain and mode are safe to overwrite from the package.
#    key/secret/init/config_version/verification_code must survive the upgrade.
# ---------------------------------------------------------------------------
log "Merging /etc/config/citypassenger..."
if [ -f /etc/config/citypassenger ]; then
    new_api_domain=$(grep "option api_domain" etc/config/citypassenger | awk '{print $3}' | tr -d "'")
    new_mode=$(grep "option mode" etc/config/citypassenger | awk '{print $3}' | tr -d "'")

    if [ -n "$new_api_domain" ]; then
        uci set citypassenger.@device[0].api_domain="$new_api_domain"
        log "Updated api_domain to: $new_api_domain"
    fi
    if [ -n "$new_mode" ]; then
        uci set citypassenger.@device[0].mode="$new_mode"
        log "Updated mode to: $new_mode"
    fi
    uci commit citypassenger
    log "Config merged (key/secret/init/config_version/verification_code preserved)"
else
    # Shouldn't happen on an upgrade, but handle gracefully
    log "WARNING: no existing config found, doing full install"
    cp etc/config/citypassenger /etc/config/citypassenger
    chmod 644 /etc/config/citypassenger
fi

# ---------------------------------------------------------------------------
# 5. Set up cron jobs
# ---------------------------------------------------------------------------
log "Setting up cron jobs..."
if [ -f "/etc/citypassenger/cronjob" ]; then
    current_crontab=$(crontab -l 2>/dev/null || echo "")
    filtered_crontab=$(echo "$current_crontab" | grep -v "/etc/citypassenger/")
    {
        echo "$filtered_crontab"
        cat /etc/citypassenger/cronjob
    } | crontab -
    log "Cron jobs configured:"
    cat /etc/citypassenger/cronjob
else
    log "WARNING: /etc/citypassenger/cronjob not found, skipping cron setup"
fi

/etc/init.d/cron enable
/etc/init.d/cron restart
log "Cron service enabled and restarted"

# ---------------------------------------------------------------------------
# 6. Install and start DNS filtering service
# ---------------------------------------------------------------------------
log "Installing DNS filtering service..."
if [ -f "etc/init.d/dns_filtering" ]; then
    cp etc/init.d/dns_filtering /etc/init.d/dns_filtering
    chmod +x /etc/init.d/dns_filtering
    /etc/init.d/dns_filtering enable
    /etc/init.d/dns_filtering restart
    log "DNS filtering service installed, enabled and started"
else
    log "WARNING: etc/init.d/dns_filtering not found, skipping"
fi

log "=== Upgrade Complete ==="
