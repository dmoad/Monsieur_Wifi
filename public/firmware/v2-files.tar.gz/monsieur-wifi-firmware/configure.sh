#!/bin/sh
# configure.sh — FRESH FLASH bootstrap.
# Copied to the device alongside the repo and run once after first flash.
# CWD must be the repo root (the directory containing this file).
# Target: OpenWrt 24 / BusyBox ash (POSIX sh only, no bash-isms)

set -e

log() { logger -t "configure.sh" "$*"; echo "$*"; }

log "=== CityPassenger Fresh-Flash Bootstrap ==="
log "Running from: $(pwd)"

# ---------------------------------------------------------------------------
# 1. Install /etc/citypassenger/
# ---------------------------------------------------------------------------
log "Installing /etc/citypassenger/..."
rm -rf /etc/citypassenger/
cp -rf src/etc/citypassenger/ /etc/citypassenger/
chmod +x /etc/citypassenger/*.sh
log "Scripts installed"

# ---------------------------------------------------------------------------
# 2. Install VERSION
# ---------------------------------------------------------------------------
if [ -f "VERSION.md" ]; then
    cp VERSION.md /etc/citypassenger/VERSION
    log "VERSION installed: $(cat VERSION.md)"
else
    log "WARNING: VERSION.md not found, skipping"
fi

# ---------------------------------------------------------------------------
# 3. Install /etc/rc.local — fresh-flash version (verify loop, sets key+secret,
#    then installs cron). After first successful verify the upgrade flow takes
#    over and will replace this with etc/citypassenger/rc.local.
# ---------------------------------------------------------------------------
# Snapshot md5 of rc.local before we touch it (may not exist on fresh flash)
rc_local_md5_before=""
if [ -f /etc/rc.local ] && [ -s /etc/rc.local ]; then
    rc_local_md5_before=$(md5sum /etc/rc.local | awk '{print $1}')
    log "rc.local md5 before install: $rc_local_md5_before"
else
    log "rc.local absent or empty before install"
fi

log "Installing /etc/rc.local (fresh-flash verify loop)..."
cp src/rc.local-on-fresh-flash /etc/rc.local
chmod +x /etc/rc.local

rc_local_md5_after=$(md5sum /etc/rc.local | awk '{print $1}')
log "rc.local md5 after install:  $rc_local_md5_after"

# Compute expected md5 directly from the source file
rc_local_md5_expected=$(md5sum src/rc.local-on-fresh-flash | awk '{print $1}')
log "rc.local md5 expected:       $rc_local_md5_expected"

if [ "$rc_local_md5_after" != "$rc_local_md5_expected" ]; then
    log "ERROR: /etc/rc.local md5 mismatch after copy — file may be corrupt"
    exit 1
fi
log "/etc/rc.local installed and verified"

# ---------------------------------------------------------------------------
# 4. Install /etc/config/citypassenger (fresh install — full copy is safe)
# ---------------------------------------------------------------------------
log "Installing /etc/config/citypassenger..."
cp src/etc/config/citypassenger /etc/config/citypassenger
chmod 644 /etc/config/citypassenger
log "Config installed"

# ---------------------------------------------------------------------------
# 5. Set model string
# ---------------------------------------------------------------------------
echo "W635ai" > /tmp/sysinfo/model
log "Model set to W635ai"

# ---------------------------------------------------------------------------
# 6. Install DNS filtering service
# ---------------------------------------------------------------------------
log "Installing DNS filtering service..."
if [ -f "src/etc/init.d/dns_filtering" ]; then
    cp src/etc/init.d/dns_filtering /etc/init.d/dns_filtering
    chmod +x /etc/init.d/dns_filtering
    /etc/init.d/dns_filtering enable
    /etc/init.d/dns_filtering restart
    log "DNS filtering service installed, enabled and started"
else
    log "WARNING: src/etc/init.d/dns_filtering not found, skipping"
fi

# NOTE: Cron is intentionally NOT set up here.
# The fresh-flash rc.local (verify loop) sets up the cron entry itself
# once the device successfully verifies with the API and receives its key+secret.

log "Running bootstrap-slots.sh..."
sh /etc/citypassenger/bootstrap-slots.sh
log "bootstrap-slots.sh complete"

# ---------------------------------------------------------------------------
# 7. Verify everything is in place before rebooting
#    Disable set -e here so all checks run and accumulate before we decide.
# ---------------------------------------------------------------------------
set +e
log "Verifying installation..."
errors=0

[ -d /etc/citypassenger ]                    || { log "ERROR: /etc/citypassenger/ missing";           errors=$((errors + 1)); }
[ -f /etc/citypassenger/push-heartbeat.sh ]  || { log "ERROR: push-heartbeat.sh missing";             errors=$((errors + 1)); }
[ -f /etc/citypassenger/update-v2.sh ]       || { log "ERROR: update-v2.sh missing";                  errors=$((errors + 1)); }
[ -f /etc/citypassenger/bootstrap-slots.sh ] || { log "ERROR: bootstrap-slots.sh missing";            errors=$((errors + 1)); }
[ -f /etc/config/citypassenger ]             || { log "ERROR: /etc/config/citypassenger missing";      errors=$((errors + 1)); }

# Re-verify rc.local md5 at the end — catches anything that touched it between install and now
if [ -f /etc/rc.local ] && [ -s /etc/rc.local ]; then
    rc_local_md5_final=$(md5sum /etc/rc.local | awk '{print $1}')
    if [ "$rc_local_md5_final" != "$rc_local_md5_expected" ]; then
        log "ERROR: /etc/rc.local md5 mismatch (got=$rc_local_md5_final expected=$rc_local_md5_expected)"
        errors=$((errors + 1))
    else
        log "rc.local md5 final check OK: $rc_local_md5_final"
    fi
else
    log "ERROR: /etc/rc.local is missing or empty at final check"
    errors=$((errors + 1))
fi

if [ "$errors" -gt 0 ]; then
    log "=== Bootstrap FAILED: $errors error(s) found, not rebooting ==="
    exit 1
fi

log "=== Fresh-Flash Bootstrap Complete ==="
log "SSH session will drop when network restarts on reboot — this is expected."
log "Rebooting in 5s..."
sleep 5
reboot -f
