# Network Client Synchronization API Documentation

## Overview
This API endpoint receives real-time network client information from OpenWRT devices, including both WiFi and wired connections. The system automatically detects client changes and pushes updates every minute when changes occur.

## Authentication
The API uses path-based authentication with device credentials:
- **Key**: Unique device identifier
- **Secret**: Device authentication secret
- **Domain**: API base URL

These credentials are configured in the OpenWRT device's UCI system under `citypassenger.@device[0]`.

## Endpoint Details

### POST `/api/devices/{key}/{secret}/clients`

**Description**: Receives network client data from OpenWRT device

**Method**: `POST`

**Content-Type**: `application/json`

**URL Parameters**:
- `key` (string): Device identification key
- `secret` (string): Device authentication secret

## Request Examples

### cURL Command
```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{
    "timestamp": "2024-01-15T10:30:45Z",
    "clients": [
      {
        "mac": "aa:bb:cc:dd:ee:ff",
        "type": "wifi",
        "interface": "phy1-ap0",
        "ssid": "monsieur-wifi",
        "signal": "-45",
        "rx_rate": "150.0",
        "tx_rate": "150.0",
        "frequency": "2.4"
      },
      {
        "mac": "11:22:33:44:55:66",
        "type": "bridge",
        "ip": "192.168.100.50",
        "interface": "br-lan.10",
        "hostname": "laptop-user",
        "network": "lan"
      }
    ],
    "summary": {
      "total_clients": 2,
      "wifi_clients": 1,
      "wired_clients": 1
    },
    "synced": false
  }' \
  "https://your-api.com/api/devices/device_key/device_secret/clients"
```

### JavaScript/Node.js Example
```javascript
const axios = require('axios');

const clientData = {
  timestamp: "2024-01-15T10:30:45Z",
  clients: [
    {
      mac: "aa:bb:cc:dd:ee:ff",
      type: "wifi",
      interface: "phy1-ap0",
      ssid: "monsieur-wifi",
      signal: "-45",
      rx_rate: "150.0",
      tx_rate: "150.0",
      frequency: "2.4"
    }
  ],
  summary: {
    total_clients: 1,
    wifi_clients: 1,
    wired_clients: 0
  },
  synced: false
};

axios.post('https://your-api.com/api/devices/device_key/device_secret/clients', clientData)
  .then(response => {
    console.log('Success:', response.data);
  })
  .catch(error => {
    console.error('Error:', error.response.data);
  });
```

### Python Example
```python
import requests
import json

url = "https://your-api.com/api/devices/device_key/device_secret/clients"
headers = {"Content-Type": "application/json"}

data = {
    "timestamp": "2024-01-15T10:30:45Z",
    "clients": [
        {
            "mac": "aa:bb:cc:dd:ee:ff",
            "type": "wifi",
            "interface": "phy1-ap0",
            "ssid": "monsieur-wifi",
            "signal": "-45",
            "rx_rate": "150.0",
            "tx_rate": "150.0",
            "frequency": "2.4"
        }
    ],
    "summary": {
        "total_clients": 1,
        "wifi_clients": 1,
        "wired_clients": 0
    },
    "synced": False
}

response = requests.post(url, headers=headers, json=data)
print(f"Status: {response.status_code}")
print(f"Response: {response.json()}")
```

## Request Payload Structure

### Root Object
```json
{
  "timestamp": "2024-01-15T10:30:45Z",
  "clients": [...],
  "summary": {...},
  "synced": false
}
```

### Field Descriptions

#### Root Level Fields
| Field | Type | Description |
|-------|------|-------------|
| `timestamp` | string | ISO 8601 UTC timestamp when data was collected |
| `clients` | array | Array of client objects (WiFi and wired) |
| `summary` | object | Statistics summary |
| `synced` | boolean | Always `false` when sent (updated locally after successful API call) |

#### WiFi Client Object
```json
{
  "mac": "aa:bb:cc:dd:ee:ff",
  "type": "wifi",
  "interface": "phy1-ap0",
  "ssid": "monsieur-wifi",
  "signal": "-45",
  "rx_rate": "150.0",
  "tx_rate": "150.0",
  "frequency": "2.4"
}
```

| Field | Type | Description |
|-------|------|-------------|
| `mac` | string | MAC address (unique identifier) |
| `type` | string | Always `"wifi"` for wireless clients |
| `interface` | string | Physical interface name (e.g., `phy1-ap0`, `phy0-ap0`) |
| `ssid` | string | Network name the client is connected to |
| `signal` | string | Signal strength in dBm (negative values, closer to 0 is better) |
| `rx_rate` | string | Receive rate in Mbps |
| `tx_rate` | string | Transmit rate in Mbps |
| `frequency` | string | Band (`"2.4"` for 2.4GHz, `"5"` for 5GHz) |

#### Wired Client Object
```json
{
  "mac": "11:22:33:44:55:66",
  "type": "bridge",
  "ip": "192.168.100.50",
  "interface": "br-lan.10",
  "hostname": "laptop-user",
  "network": "lan"
}
```

| Field | Type | Description |
|-------|------|-------------|
| `mac` | string | MAC address (unique identifier) |
| `type` | string | `"wired"` or `"bridge"` depending on connection method |
| `ip` | string | Assigned IP address |
| `interface` | string | Interface name (e.g., `br-lan.10`, `br-lan.1`) |
| `hostname` | string | Device hostname from DHCP lease (may be empty) |
| `network` | string | Network segment (`"lan"` or `"captive"`) |

#### Summary Object
```json
{
  "total_clients": 2,
  "wifi_clients": 1,
  "wired_clients": 1
}
```

| Field | Type | Description |
|-------|------|-------------|
| `total_clients` | integer | Total number of connected clients |
| `wifi_clients` | integer | Number of WiFi clients |
| `wired_clients` | integer | Number of wired/bridge clients |

## Response Format

### Success Response
```json
{
  "status": "success"
}
```

**OR**

```json
{
  "success": true
}
```

### Error Response
```json
{
  "status": "error",
  "message": "Detailed error description"
}
```

## HTTP Status Codes

| Code | Description |
|------|-------------|
| `200` | Success - Client data processed successfully |
| `400` | Bad Request - Invalid JSON or missing required fields |
| `401` | Unauthorized - Invalid device key/secret |
| `404` | Not Found - Device not found |
| `500` | Internal Server Error - Server processing error |

## Implementation Examples

### Express.js (Node.js) Handler
```javascript
app.post('/api/devices/:key/:secret/clients', async (req, res) => {
  try {
    const { key, secret } = req.params;
    const clientData = req.body;
    
    // Validate device credentials
    const device = await validateDevice(key, secret);
    if (!device) {
      return res.status(401).json({ status: 'error', message: 'Invalid credentials' });
    }
    
    // Validate payload structure
    if (!clientData.timestamp || !Array.isArray(clientData.clients)) {
      return res.status(400).json({ status: 'error', message: 'Invalid payload structure' });
    }
    
    // Process client data
    await processClientData(device.id, clientData);
    
    // Log activity
    console.log(`Device ${key}: ${clientData.summary.total_clients} clients synced`);
    
    res.json({ status: 'success' });
  } catch (error) {
    console.error('Client sync error:', error);
    res.status(500).json({ status: 'error', message: 'Internal server error' });
  }
});
```

### Django (Python) Handler
```python
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
import json

@csrf_exempt
@require_http_methods(["POST"])
def client_sync(request, key, secret):
    try:
        # Validate device credentials
        device = validate_device(key, secret)
        if not device:
            return JsonResponse({'status': 'error', 'message': 'Invalid credentials'}, status=401)
        
        # Parse JSON payload
        client_data = json.loads(request.body)
        
        # Validate payload structure
        if 'timestamp' not in client_data or 'clients' not in client_data:
            return JsonResponse({'status': 'error', 'message': 'Invalid payload structure'}, status=400)
        
        # Process client data
        process_client_data(device.id, client_data)
        
        # Log activity
        total_clients = client_data.get('summary', {}).get('total_clients', 0)
        print(f"Device {key}: {total_clients} clients synced")
        
        return JsonResponse({'status': 'success'})
        
    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)
    except Exception as e:
        print(f"Client sync error: {e}")
        return JsonResponse({'status': 'error', 'message': 'Internal server error'}, status=500)
```

### PHP Handler
```php
<?php
header('Content-Type: application/json');

// Get URL parameters
$key = $_GET['key'] ?? '';
$secret = $_GET['secret'] ?? '';

// Validate HTTP method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit;
}

// Validate device credentials
$device = validateDevice($key, $secret);
if (!$device) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Invalid credentials']);
    exit;
}

// Parse JSON payload
$input = file_get_contents('php://input');
$clientData = json_decode($input, true);

// Validate payload structure
if (!isset($clientData['timestamp']) || !isset($clientData['clients'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid payload structure']);
    exit;
}

try {
    // Process client data
    processClientData($device['id'], $clientData);
    
    // Log activity
    $totalClients = $clientData['summary']['total_clients'] ?? 0;
    error_log("Device $key: $totalClients clients synced");
    
    echo json_encode(['status' => 'success']);
} catch (Exception $e) {
    error_log("Client sync error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Internal server error']);
}
?>
```

## Data Processing Considerations

### Change Detection
The OpenWRT device only sends data when client changes are detected (connections/disconnections). Your API should:
- Store the latest client state per device
- Compare with previous state to identify changes
- Track connection/disconnection events
- Update device status and activity logs

### Client Identification
- Use MAC addresses as unique identifiers
- Store historical connection data
- Track client patterns and usage
- Associate clients with device networks (main WiFi vs captive portal)

### Network Segmentation
Clients are categorized by network:
- `"lan"`: Main password-protected WiFi network
- `"captive"`: Guest/captive portal network

### Interface Mapping
- `phy1-ap0`, `phy0-ap0`: Main WiFi networks
- `phy1-ap1`, `phy0-ap1`: Captive portal networks  
- `br-lan.10`: VLAN 10 (typically main network)
- `br-lan.1`: VLAN 1 (typically captive portal)

## Security Considerations

1. **Authentication**: Validate device key/secret combinations
2. **Rate Limiting**: Implement rate limiting per device
3. **Data Validation**: Validate all incoming data fields
4. **MAC Address Privacy**: Consider MAC address privacy implications
5. **Logging**: Log all API calls for security monitoring

## Monitoring and Alerts

Consider implementing:
- Device connectivity monitoring
- Client count anomaly detection
- Network performance metrics
- Connection pattern analysis
- Security event detection

## Testing

Test your API with sample payloads:
```bash
# Test with no clients
curl -X POST -H "Content-Type: application/json" \
  -d '{"timestamp":"2024-01-15T10:30:45Z","clients":[],"summary":{"total_clients":0,"wifi_clients":0,"wired_clients":0},"synced":false}' \
  "https://your-api.com/api/devices/test_key/test_secret/clients"

# Test with multiple clients
curl -X POST -H "Content-Type: application/json" \
  -d '{"timestamp":"2024-01-15T10:30:45Z","clients":[{"mac":"aa:bb:cc:dd:ee:ff","type":"wifi","interface":"phy1-ap0","ssid":"test","signal":"-45","rx_rate":"150.0","tx_rate":"150.0","frequency":"2.4"}],"summary":{"total_clients":1,"wifi_clients":1,"wired_clients":0},"synced":false}' \
  "https://your-api.com/api/devices/test_key/test_secret/clients"
```

This documentation provides everything needed to implement the API service to handle OpenWRT network client synchronization payloads. 