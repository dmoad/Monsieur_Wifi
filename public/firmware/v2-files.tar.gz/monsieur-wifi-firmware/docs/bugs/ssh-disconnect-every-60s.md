# Bug: SSH Session Dropped — Full Network Restart on Every `update-v2.sh` Run

**File:** `src/etc/citypassenger/update-v2.sh`
**Lines:** 1167–1199 (Phase 6)
**Severity:** High — dropping the SSH session every time `update-v2.sh` is triggered makes the device unmanageable during provisioning

---

## Symptom

When connected to the device via SSH, the session is forcibly dropped whenever `update-v2.sh` completes. The device itself does not reboot — it recovers within ~8 seconds — but the active SSH connection is terminated.

Observed in `logread` (single boot sequence):
```
Mon Mar  9 10:44:20  procd: /etc/rc.d/S95done: Restoring config from /root/backup_config...
...
Mon Mar  9 10:44:21  netifd: Interface 'lan' is now down        ← SSH dropped here
...
Mon Mar  9 10:44:32  netifd: Interface 'lan' is now up
...
Mon Mar  9 10:45:35  dropbear: Password auth succeeded for 'root' from 192.168.89.115
Mon Mar  9 10:46:28  dropbear: Exit (root): Error reading: Connection reset by peer  ← dropped again
```

The `br-lan` bridge tears down and comes back up each time the script runs, resetting all TCP connections including SSH.

---

## Trigger

`update-v2.sh` is **not on a cron**. It is triggered on-demand — currently via `S95done` at boot (which restores config and calls the update script), and whenever the server signals a config version change via `push-heartbeat.sh → update.sh`. The disconnect is a one-time event per run, not a repeating cycle.

The second disconnect seen at `10:46:28` (above) is from the same boot-time run of `S95done` — the user connected at `10:45:35` while the Phase 6 restart was still settling, and was dropped when the next service restart in the sequence fired. This is not a 60-second repeating cron — that assumption in the earlier version of this document was wrong.

---

## Root Cause

`update-v2.sh` Phase 6 (lines 1159–1199) unconditionally restarts every service after committing UCI config, regardless of whether anything actually changed:

```sh
# update-v2.sh lines 1167–1199

uci commit wireless
uci commit network
uci commit dhcp
uci commit chilli

# Network restart (always needed for VLAN changes)   ← comment is wrong; not always needed
echo "Restarting network..."
/etc/init.d/network restart                          ← unconditional, kills SSH
sleep 8
ensure_bridge_configuration

# Firewall reload (picks up new lan zone members)
echo "Reloading firewall..."
/etc/init.d/firewall reload                          ← unconditional

# Wireless restart
if [ "$radio_changed" = "true" ]; then
    wifi down; sleep 3; wifi up
else
    wifi reload                                      ← unconditional
fi

echo "Restarting chilli..."
/etc/init.d/chilli restart                          ← unconditional

echo "Restarting dnsmasq..."
/etc/init.d/dnsmasq restart                         ← unconditional
```

`uci commit` is always a no-op when config is already in sync with disk — it never fails, never signals "nothing changed". So after the first successful run (config now matches API), every subsequent run still commits (no-op) and then restarts everything anyway.

---

## Secondary Bug

`uci commit firewall` is **missing** from Phase 6. The `configure_firewall_zones` function writes UCI firewall changes, but they are never committed to disk. The `/etc/init.d/firewall reload` that follows reads the already-committed on-disk config, so firewall zone changes from the API are silently lost across reboots.

---

## Proposed Fix

Call `uci changes <package>` **before** committing. Once committed the pending changes list is cleared, so this must happen first. Gate each service restart on whether its config actually changed:

```sh
# Check for pending changes BEFORE committing
network_changed=false; wireless_changed=false; dhcp_changed=false
chilli_changed=false; firewall_changed=false

uci changes network  | grep -q . && network_changed=true
uci changes wireless | grep -q . && wireless_changed=true
uci changes dhcp     | grep -q . && dhcp_changed=true
uci changes chilli   | grep -q . && chilli_changed=true
uci changes firewall | grep -q . && firewall_changed=true

echo "Changes -- network:$network_changed wireless:$wireless_changed dhcp:$dhcp_changed chilli:$chilli_changed firewall:$firewall_changed"

uci commit wireless
uci commit network
uci commit dhcp
uci commit chilli
uci commit firewall   # also fixes the missing firewall commit bug

if [ "$network_changed" = "true" ]; then
    echo "Network config changed, restarting network..."
    /etc/init.d/network restart
    sleep 8
    ensure_bridge_configuration
else
    echo "No network changes, skipping network restart."
fi

if [ "$firewall_changed" = "true" ] || [ "$network_changed" = "true" ]; then
    echo "Reloading firewall..."
    /etc/init.d/firewall reload
else
    echo "No firewall changes, skipping firewall reload."
fi

if [ "$wireless_changed" = "true" ] || [ "$radio_changed" = "true" ]; then
    if [ "$radio_changed" = "true" ]; then
        echo "Radio settings changed, performing full WiFi restart..."
        wifi down; sleep 3; wifi up
    else
        echo "Wireless config changed, performing WiFi reload..."
        wifi reload
    fi
else
    echo "No wireless changes, skipping WiFi restart."
fi

if [ "$chilli_changed" = "true" ] || [ "$network_changed" = "true" ]; then
    echo "Restarting chilli..."
    /etc/init.d/chilli restart
else
    echo "No chilli changes, skipping chilli restart."
fi

if [ "$dhcp_changed" = "true" ] || [ "$network_changed" = "true" ]; then
    echo "Restarting dnsmasq..."
    /etc/init.d/dnsmasq restart
else
    echo "No DHCP changes, skipping dnsmasq restart."
fi
```

**Result:** When the API returns config identical to what is already running (i.e. every run after the first), all five service restarts are skipped. The SSH session survives. Service restarts still fire normally on the first provisioning run or when the API sends a genuine config change.

---

## Impact of Fix

| Service | Before | After |
|---|---|---|
| `network restart` | Every run | Only when network/VLAN config changed |
| `firewall reload` | Every run | Only when firewall or network config changed |
| `wifi reload`/restart | Every run | Only when wireless config or radio settings changed |
| `chilli restart` | Every run | Only when chilli or network config changed |
| `dnsmasq restart` | Every run | Only when DHCP or network config changed |
| firewall UCI commit | **Never** (bug) | Every run (fixes silent firewall loss on reboot) |
